--select * from sys.objects where type_desc in ('PRIMARY_KEY_CONSTRAINT','FOREIGN_KEY_CONSTRAINT')
CREATE VIEW metadata.vw_FK_References
AS
SELECT 
	f.object_id,
	OBJECT_NAME(f.object_id) as FK_Name,
	f.parent_object_id ,
    OBJECT_NAME(f.parent_object_id) Table_Name,
    COL_NAME(fk.parent_object_id,fk.parent_column_id) Column_Name,
    t.object_id as referenced_object_id,
	OBJECT_NAME(fk.referenced_object_id) as ReferencedTable_Name,
    COL_NAME(fk.referenced_object_id,fk.referenced_column_id) as ReferencedColumn_Name

FROM sys.foreign_keys AS f
    INNER JOIN sys.foreign_key_columns AS fk 
        ON f.OBJECT_ID = fk.constraint_object_id
    INNER JOIN sys.tables t
        ON fk.referenced_object_id = t.object_id

WHERE 1=1
	--and OBJECT_NAME(fk.referenced_object_id) = 'your table name'
	--and OBJECT_NAME(f.parent_object_id) like 'mbi%' 
    --and COL_NAME(fk.referenced_object_id,fk.referenced_column_id) = 'your key column name'

