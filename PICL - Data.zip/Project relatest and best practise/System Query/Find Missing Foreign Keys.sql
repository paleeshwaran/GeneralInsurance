WITH FK AS (
	select
		t.name+'.'+c.name as FK_Name,
		t.name as TableWithForeignKey, 
		fk.constraint_column_id as FK_PartNo, 
		c.name as ForeignKeyColumn 
		,fk.*
		--,t2.name
		--,c2.name
	from sys.foreign_key_columns as fk
	inner join sys.tables as t 
		on fk.parent_object_id = t.object_id
	inner join sys.columns as c 
		on fk.parent_object_id = c.object_id 
		and fk.parent_column_id = c.column_id

		select * from sys.check_constraints
		)
,ID as (
	select 
	t.name+'.'+c.name as FK_Name
	,t.name as TableName
	,c.name as ColumnName
	from sys.tables t
	left join sys.columns c on c.object_id=t.object_id
	where c.name like'%_id'
	)

SELECT * 
FROM ID
LEFT JOIN FK on ID.FK_Name=FK.FK_Name
ORDER BY 3,2


