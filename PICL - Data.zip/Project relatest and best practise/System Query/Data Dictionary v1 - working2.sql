
select
	s.schema_id
	,s.name as schema_name
	,t.object_id
	,t.name as table_name
	--,case when charindex('_',t.name)=0 
/*,case 
	when t.name in 
	--general tables with an "_":
		(
		'agent_account_hash'
		,'deactivate_request'
		,'job_schedule'
		,'lock_out'
		,'login_attempt'
		,'insurance_product'
		,'monthly_policy_counts'
		,'past_password'
		,'policy_status_history'
		,'policy_warnings'
		,'reset_password_token'
		,'transactional_emails'
		,'xero_refund'
		) then t.name
	else left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
	end as table_root
	*/
from sys.tables t
join sys.schemas s on s.schema_id=t.schema_id
left join (
	select distinct
		case when t.name in 
		--general tables with an "_":
		(
		'agent_account_hash'
		,'authorized_signatories'
		,'booklet_override'
		,'country_of_origin'
		,'deactivate_request'
		,'job_schedule'
		,'lock_out'
		,'login_attempt'
		,'insurance_product'
		,'monthly_policy_counts'
		,'past_password'
		,'policy_status_history'
		,'policy_warnings'
		,'reset_password_token'
		,'transactional_emails'
		,'xero_refund'
		) then ''
		else left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
		end as table_root
		,t.name
	from sys.tables t
	--order by 2,1
	)X
	on X.object_id=t.object_id
--order by 2
/*
select distinct type_desc
from sys.objects
*/


	select distinct
		case when t.name in 
		--general tables with an "_":
		(
		'agent_account_hash'
		,'authorized_signatories'
		,'booklet_override'
		,'country_of_origin'
		,'crawford_incident_type'
		,'credit_note'
		,'deactivate_request'
		,'job_schedule'
		,'lock_out'
		,'login_attempt'
		,'insurance_product'
		,'monthly_policy_counts'
		,'past_password'
		,'policy_status_history'
		,'policy_warnings'
		,'reset_password_token'
		,'transactional_emails'
		,'xero_refund'
		) then 'general'
		else 
			case when charindex('_',t.name)=0 
				and t.name in --(select t.name from sys.tables t where charindex('_',t.name)=0)
					(select distinct left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) from sys.tables t)
				then t.name
			else left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
			end
		end as table_root
		,t.name
		,left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
	from sys.tables t
	order by 2,1

select
	s.name as schema_name
	,t.name
	,left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
	,case when left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) not in (
			select 
			t.name
			from sys.tables t
			where charindex('_',t.name)=0
			) then 'general' 
		else left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
		end
from sys.tables t
join sys.schemas s on s.schema_id=t.schema_id

select 
s.schema_id
,s.name as schema_name
,t.object_id
,t.name
,case 
	when charindex('_',t.name)=0 
		and t.name in --(select t.name from sys.tables t where charindex('_',t.name)=0)
			(select distinct left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) from sys.tables t)
		then t.name
	when charindex('_',t.name)=0 
		and t.name not in --(select t.name from sys.tables t where charindex('_',t.name)=0)
			(select distinct left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) from sys.tables t)
		then 'general'
	else 
		case 
		when t.name in (
			'country_of_origin'
			,'crawford_incident_type'
			,'credit_note'
			,'deactivate_request'
			,'finance_company'
			,'insurance_product'
			) then 'general'
		when t.name in (
			'agent_account_hash'
			,'authorized_signatories'
			,'booklet_override'
			,'ecm_doc_type'
			,'epb_delivery_details'
			,'login_attempt'
			,'monthly_policy_counts'
			,'past_password'
			,'policy_status_history'
			,'policy_warnings'
			,'report_rerun'
			,'reset_password_token'
			,'transactional_emails'	
			,'xero_refund'
			) then 'technical'
		else left(t.name,case when charindex('_',t.name)=0 then 0 else charindex('_',t.name)-1 end) 
		end
	end as table_group
from sys.tables t
join sys.schemas s on s.schema_id=t.schema_id
order by 2,5,4



select * from picllivedb.service_agent_types