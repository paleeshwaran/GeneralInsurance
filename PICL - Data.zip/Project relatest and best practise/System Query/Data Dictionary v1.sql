DECLARE @date nvarchar(max)

select 
	ROW_NUMBER() over (
		partition by s.name,t.name
		order by s.name,t.name,c.column_id
		) as RowNum
	,t.object_id
	,s.name	as 'schema_name'
	,t.name	as 'table_name'
	,c.name as 'column_name'
	,c.column_id
	,ty.name
		+case 
			when ty.name in ('decimal','float','money','numeric','real','smallmoney') then '('+convert(varchar,c.precision)+','+convert(varchar,c.scale)+')'	
			when ty.name in ('char','nchar','nvarchar','varchar') then '('+case when c.max_length=-1 then 'max' else convert(varchar,c.max_length) end+')'
			else ''	
		end 
		+case when c.is_nullable=0 then ' NULL' else ' NOT NULL' end -- add nullability for column
		as 'Full_Column_type'
	,ty.name
	,c.max_length	
	,c.precision	
	,c.scale	
	,c.collation_name	
	,c.is_nullable
	--,ty.*
	--,c.*
from sys.tables t
join sys.columns c on c.object_id=t.object_id
join sys.schemas s on s.schema_id=t.schema_id
join sys.types ty 
	on ty.system_type_id=c.system_type_id
	and ty.system_type_id=ty.user_type_id
order by s.name	
	,t.name	
	,c.column_id
/*
select * from sys.types

select Row_Number() over (
	order by name ) as ROW_NUM
,name
,max_column_id_used
from sys.tables t

select * from sys.types
*/