
;WITH TABLES_ROOT_COUNT as (--table root names by count
	select left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) as table_root
	,count(*) as root_count
	from sys.tables
	where charindex('_',name)<>0
	group by left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)
	--order by 2 desc
)
,ROOT_TABLES as (--tables where name equals group
	SELECT  'General' as Table_Group
	,Table_SubGroup
	,t.name as Table_Name
	FROM sys.tables t
	JOIN (
	select left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) as Table_SubGroup
	,count(*) as group_count
	from sys.tables
	where charindex('_',name)<>0
	group by left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)
	)X on X.Table_SubGroup=t.name
	--order by 1
)
,TABLE_GROUPS AS (
	select 
	case when r.Table_Group is null then 
	case when charindex('_',name)=0 then 'General' 
	else case
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('posm','mvi','cci','tar','gap','mbi','lnm','lpi') then 'Products'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Dealer') then 'Dealer'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Vehicle') then 'Vehicle'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Rb','Redbook') then 'Redbook'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Policy') then 'Policy'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Payment') then 'Payment'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Invoice') then 'Invoice'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Archive') then 'Archive'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Import') then 'Import'
	when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('user') then 'user'
	else 'General' 
	end
	end
	else r.Table_Group 
	end as Table_Group
	,case when charindex('_',name)=0 then name
	else COALESCE(r.Table_SubGroup,left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)) 
	end as Table_SubGroup
	,t.name 
	from sys.tables t
	left join ROOT_TABLES r on r.Table_Name=t.name
	where 1=1
	--and charindex('_',name)<>0
	--order by name
)


SELECT 	--*	
Table_Group	
,Table_Leaf_name
,SUM(isnull([posm],0)
	+isnull([mbi],0)
	+isnull([tar],0)
	+isnull([gap],0) 
	+isnull([cci],0)
	)as COUNT_LEAVES
,sum(isnull([posm],0)) as [posm]
,sum(isnull([mbi],0)) as [mbi]
,sum(isnull([tar],0)) as [tar]
,sum(isnull([gap],0)) as [gap]
,sum(isnull([cci],0)) as [cci]
FROM (
	select 
		Table_Group	
		,Table_SubGroup	
		,right(name,len(name)-charindex('_',name)) as Table_Leaf_name
		,1 as dummy_count
		--,name as Table_Name
	from TABLE_GROUPS 
	where Table_Group='Products'
	and Table_SubGroup in ('posm','mbi','tar','gap','cci')
	)X
PIVOT (
	sum(dummy_count)
	FOR Table_SubGroup in ([posm],[mbi],[tar],[gap],[cci])
	)PVT
GROUP BY Table_Group	,Table_Leaf_name
ORDER BY 3 desc,2
/*
SELECT
Table_Group
,Table_SubGroup 
,t.name as table_name
,sum(isnull(X.Count_Datetime,0)) as Count_Datetime
,sum(isnull(X.Table_Score,0)) as Score
FROM sys.tables t
LEFT JOIN (
select 
t.object_id
,t.name as Table_Name
,c.name as Column_name 
,st.name as SysType_Name
,1 as Count_Datetime
,case 
when c.name like '%created%' then 3
when c.name like '%updated%' then 4
else 0 end as Table_Score
--,c.*
from sys.tables t
join sys.columns c on c.object_id=t.object_id
join sys.systypes st on st.xtype=c.system_type_id
where st.name like '%datetime%'
and t.name not like 'archive%'
)X on X.object_id=t.object_id
LEFT JOIN TABLE_GROUPS tg on tg.name=t.name
GROUP BY Table_Group,Table_SubGroup ,t.name
*/
/*
select 
t.object_id
,t.name as Table_Name
,c.name as Column_name 
,st.name as SysType_Name
from sys.tables t
join sys.columns c on c.object_id=t.object_id
join sys.systypes st on st.xtype=c.system_type_id
where 1=1
and ( c.name like '%created%'
or c.name like '%updated%')
*/

select * from sys.foreign_keys