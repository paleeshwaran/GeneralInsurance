
;WITH TABLES_ROOT_COUNT as (--table root names by count
	select left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) as table_root
	,count(*) as root_count
	from sys.tables
	where charindex('_',name)<>0
	group by left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)
	--order by 2 desc
	)
,ROOT_TABLES as (--tables where name equals group
	SELECT  'General' as Table_Group
	,Table_SubGroup
	,t.name as Table_Name
	FROM sys.tables t
	JOIN (
		select left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) as Table_SubGroup
		,count(*) as group_count
		from sys.tables
		where charindex('_',name)<>0
		group by left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)
		)X on X.Table_SubGroup=t.name
	--order by 1
	)
,TABLE_GROUPS AS (
	select 
		case when r.Table_Group is null then 
				case when charindex('_',name)=0 then 'General' 
					else case
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('posm','mvi','cci','tar','gap','mbi','lnm','lpi') then 'Products'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Dealer') then 'Dealer'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Vehicle') then 'Vehicle'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Rb','Redbook') then 'Redbook'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Policy') then 'Policy'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Payment') then 'Payment'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Invoice') then 'Invoice'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Archive') then 'Archive'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('Import') then 'Import'
						when left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end) in ('user') then 'user'
						else 'General' 
						end
					end
			else r.Table_Group 
			end as Table_Group
		,case when charindex('_',name)=0 then name
			else COALESCE(r.Table_SubGroup,left(name,case when charindex('_',name)=0 then 0 else charindex('_',name)-1 end)) 
			end as Table_SubGroup
		,t.name 
	from sys.tables t
	left join ROOT_TABLES r on r.Table_Name=t.name
	where 1=1
	--and charindex('_',name)<>0
	--order by name
	)


select tg.Table_Group	,Table_SubGroup	,name
from TABLE_GROUPS tg
order by Table_Group ,Table_SubGroup ,name