
USE DebitSuccess
GO
ALTER PROCEDURE dbo.DS_ClientDetails
AS 
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--CREATE TABLE
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('dbo.ClientListing', 'U') IS NOT NULL 
	DROP TABLE  dbo.ClientListing 
CREATE TABLE dbo.ClientListing
	(
	Business			nvarchar(max),
	BusinessAccount		nvarchar(max),
	Name				nvarchar(max),
	Address				nvarchar(max),
	Email				nvarchar(max),
	Phone	 			nvarchar(max),
	DebitsuccessID		nvarchar(max),
	BusinessID			nvarchar(max),
	Signed				nvarchar(max),
	StartDate			nvarchar(max),
	Term				nvarchar(max),
	PayMethod			nvarchar(max),
	Frequency			nvarchar(max),
	Instalment			nvarchar(max)
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--INSERT DATA from csv
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
TRUNCATE TABLE dbo.ClientListing
BULK INSERT dbo.ClientListing
FROM 'C:\DebitSuccess\Debit Success Client Listing.csv'
--'C:\SharePoint\Provident Insurance\Shared Documents - Documents\IT\Datawarehouse\002-Discovery\Integrations\McLarens\Integral Integration Reconciliation\DB csv\PVT-Transactions_2021-02-28.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

--select top 10 * from dbo.ClientListing
;WITH PICLOS AS (
	select 
	'PMV' as Product
	,convert(varchar,id) as id
	,policy_number
	,status
	,from_timestamp
	,to_timestamp
	,payment_type	
	,case 
		when payment_freq='M' then 'Monthly'
		when payment_freq='F' then 'Fortnightly'
		when payment_freq='W' then 'Weekly'
		when payment_freq='Y' then 'Yearly'
		end as payment_freq
	--,title_1	
	,last_name_1+'; '+first_name_1 as ClientName
	,street ,suburb ,city ,postcode
	,replace(street,',',';')+'; '
		+replace(suburb,',',';')+'; '
		+replace(city,',',';')+'; '
		+case when left(postcode,1)='0' then right(postcode,len(postcode)-1) else postcode end
		as ClientAddress
	,email	
	,day_phone	
	,right(day_phone,4) as Phone_End
	,other_phone
	,work_phone
	--,* 
	from [PRODDWPICL.DATABASE.WINDOWS.NET].[prodsqlpiclos].[picllivedb].[posm_policy]
	where 1=1
	--and status='V'
	and payment_type not in ('Cash','Dealer Arranged')
	/*and (policy_number='55125569-2'
		or email='skinny987@gmail.com'
		or day_phone='021 087 14336'
		)*/

		UNION

	select 
	'MBI' as Product
	,convert(varchar,id) as id
	,convert(varchar,id) as policy_number
	,status
	,from_timestamp
	,to_timestamp
	,'Direct Debit' as Payment_Type	
	,isnull(payment_frequency,'N/A')
	--,title_1	
	,last_name_1+'; '+first_name_1 as ClientName
	,street ,suburb ,city ,postcode
	,replace(street,',',';')+'; '
		+replace(suburb,',',';')+'; '
		+replace(city,',',';')+'; '
		+case when left(postcode,1)='0' then right(postcode,len(postcode)-1) else postcode end
		as ClientAddress
	,email	
	,day_phone	
	,right(day_phone,4) as Phone_End
	,other_phone
	,NULL AS work_phone
	--,*
	from [PRODDWPICL.DATABASE.WINDOWS.NET].[prodsqlpiclos].[picllivedb].[mbi_policy] 
	where 1=1
	--and status='V'
	--and isnull(payment_frequency,'N/A')<>'N/A'
	)
,MATCHING AS (
	select 
		P.Product
		,isnull(isnull(DS.BusinessID,P.policy_number),P2.id) as policy_number	
		,P.status
		,StartDate	,Term	,Instalment
		,DS.Name as DS_ClientName
		,isnull(P.ClientName,P2.ClientName) as ClientName
			,case when DS.Name COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.ClientName,P2.ClientName) then 0 else 1 end as Flag_Name
		,DS.Address	as DS_ClientAddress
		,isnull(P.ClientAddress,P2.ClientAddress) as ClientAddress 
			,case when DS.Address COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.ClientAddress,P2.ClientAddress)  then 0 else 1 end as Flag_Address
		,isnull(DS.Email,'')	as DS_Email
		,isnull(P.email,P2.email) as email
			,case when isnull(DS.Email,'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.email,P2.email) then 0 else 1 end as Flag_Email
		,isnull(DS.Phone,'') as DS_Phone
		,isnull(P.day_phone,P2.day_phone)
			,case when isnull(DS.Phone,'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.day_phone,P2.day_phone) then 0 else 1 end as Flag_Phone
		,isnull(RIGHT(DS.Phone,4),'') as DS_Phone_End
		,isnull(isnull(P.Phone_End,P2.Phone_End),'') as Phone_End
			,case when isnull(RIGHT(DS.Phone,4),'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.Phone_End,P2.Phone_End) then 0 else 1 end as Flag_Phone_End
		,DS.PayMethod 
		,isnull(P.payment_type,P2.payment_type) as payment_type
			,case when DS.PayMethod COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_type,P2.payment_type) then 0 else 1 end as Flag_Payment_type
		,DS.Frequency as DS_Frequency
		,isnull(P.payment_freq,P2.payment_freq) as payment_freq
			,case when DS.Frequency COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_freq,P2.payment_freq) then 0 else 1 end as Flag_Frequency
	from dbo.ClientListing DS
	left join PICLOS P 
		on P.policy_number=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	left join PICLOS P2
		on P2.id=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	where 1=1
	--and (DS.BusinessID='55125569-2'
	--	or DS.email='skinny987@gmail.com'
	--	or DS.phone='021 087 14336'
	--	)
	)
SELECT M.*
,case when Flag_Address+Flag_Email+Flag_Phone>=1 then 'Error' else 'OK' end as ClientDetails_Error
,case when Flag_Payment_type+Flag_Frequency<>0 then 'Error' else 'OK' end as Payment_Error
FROM MATCHING M

--where policy_number='50000080-6'
/*
	select 
	id
	,policy_number
	,status
	,payment_type	
	,case 
		when payment_freq='M' then 'Monthly'
		when payment_freq='F' then 'Fortnightly'
		when payment_freq='W' then 'Weekly'
		when payment_freq='Y' then 'Yearly'
		end as payment_freq
	--,title_1	
	,last_name_1+'; '+first_name_1 as ClientName
	,street ,suburb ,city ,postcode
	,replace(street,',',';')+'; '
		+replace(suburb,',',';')+'; '
		+replace(city,',',';')+'; '
		+case when left(postcode,1)='0' then right(postcode,len(postcode)-1) else postcode end
		as ClientAddress
	,email	
	,day_phone	
	,other_phone
	,work_phone
	--,* 
	from [PRODDWPICL.DATABASE.WINDOWS.NET].[prodsqlpiclos].[picllivedb].[posm_policy]
	where 1=1
	and policy_number='50000080-6'
	--and status='V'
	--and payment_type not in ('Cash','Dealer Arranged')
*/