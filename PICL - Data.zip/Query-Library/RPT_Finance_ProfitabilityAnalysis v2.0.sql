USE Profitablity_test
GO
/*
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--VARIABLES:
DECLARE 
	@PATH varchar(max)
		
SET @PATH='C:\Finance\Profitability_Analysis\SQL\Load_Files\'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--CREATE TABLES
drop table Fact_Financials
CREATE TABLE Fact_Financials
	(

	snapshot_date			int,
	Account_Code			nvarchar(max),
	Weight					int,
	GL_Code					nvarchar(max),
	GL_Split				nvarchar(max),
	FC_GL_Code				nvarchar(max),
	GLOrder					nvarchar(max),
	Xero_Acct_Name			nvarchar(max),
	Xero_Acct_Description	nvarchar(max),
	Account_Group_Code		nvarchar(max),
	Account_Group			nvarchar(max),
	Account_Type			nvarchar(max),
	Xero_Tax_Class			nvarchar(max),
	GLLevel_1				nvarchar(max),
	GLLevel_2				nvarchar(max),
	GLLevel_3				nvarchar(max),
	GLLevel_4				nvarchar(max),
	GLLevel_5				nvarchar(max),
	GLLevel_6				nvarchar(max),
	GLLevel_7				nvarchar(max),
	GLLevel_8				nvarchar(max),
	Actual_Debit_MTD 	 	float,
	Actual_Credit_MTD 	 	float,
	Actual_Balance_MTD 		float,
	Actual_Debit_YTD 	 	float,
	Actual_Credit_YTD 	 	float,
	Actual_Balance_YTD 	 	float,
	Budget_MTD 	 			float,
	Budget_YTD 	 			float,
	)
drop table Dim_GL_Accounts
create table Dim_GL_Accounts
/*	(
	Account_Code		varchar(20),
	Xero_Account_Name	varchar(250),
	Xero_Account_Type	varchar(250),
	GL_SPLIT			varchar(20),
	GL_TYPE				varchar(20),
	GL_Code				varchar(20),
	GLOrder				varchar(20),
	FC_GL_CODE			varchar(20),
	GLLevel_1			varchar(250),
	GLLevel_2			varchar(250),
	GLLevel_3			varchar(250),
	GLLevel_4			varchar(250),
	GLLevel_5			varchar(250),
	GLLevel_6			varchar(250),
	GLLevel_7			varchar(250),
	GLLevel_8			varchar(250),
	GL_Weight			int
	)
*/
	(
	Account_Code				varchar(20)
	,Weight						int
	,GL_Code					varchar(20)
	,GL_Split					varchar(20)
	,FC_GL_Code					varchar(20)
	,GLOrder					varchar(20)
	,Xero_Acct_Name				varchar(250)
	,Xero_Acct_Description		varchar(max)
	,Account_Group_Code			varchar(250)
	,Account_Group				varchar(250)
	,Account_Type				varchar(250)
	,Xero_Tax_Class				varchar(250)
	,GLLevel_1					varchar(250)
	,GLLevel_2					varchar(250)
	,GLLevel_3					varchar(250)
	,GLLevel_4					varchar(250)
	,GLLevel_5					varchar(250)
	,GLLevel_6					varchar(250)
	,GLLevel_7					varchar(250)
	,GLLevel_8					varchar(250)
	)

create table Dim_ProfitabilityMatrix
	(
	SplitType		varchar(20),
	Product_id		int,
	Product_name	varchar(250),
	Split			float
	)

create table Dim_Date
	(
	Snapshot_date			int,
	Calendar_date			datetime,
	Financial_year			varchar(4),
	Financial_year_num		int,
	Financial_month_num		int
	)

CREATE TABLE Dim_Strawman
	(
	Account_Code	varchar(20)	NOT NULL,
	GL_Code_SM		varchar(20),
	SM_Split		float
	)

create table Dim_Product
	(
	Product_id			varchar(100),
	Product_name		varchar(100),
	Product_group_code	varchar(100),
	ProductGroup		varchar(100)
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

--BULK INSERT DATA
TRUNCATE TABLE [dbo].[Fact_Financials]
BULK INSERT [dbo].[Fact_Financials]
FROM ''\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\DATA.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_GL_Accounts
BULK INSERT dbo.Dim_GL_Accounts
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_GL_Account.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_ProfitabilityMatrix 
BULK INSERT dbo.Dim_ProfitabilityMatrix
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_ProfitabilityMatrix.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Date
BULK INSERT dbo.Dim_Date
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_Date.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Strawman
BULK INSERT dbo.Dim_Strawman
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_Strawman.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Strawman
BULK INSERT dbo.Dim_Strawman
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_Strawman.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Product
BULK INSERT dbo.Dim_Product
FROM '\SharePoint\Provident Insurance\Shared Documents - Documents\Finance\Profitability Analysis Reporting\FY21\Template\SQL_Output\Dim_Products.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
/*
select * from dbo.Fact_Financials
select * from dbo.Dim_GL_Accounts
select * from dbo.Dim_ProfitabilityMatrix  
*/
select top 5 * from [dbo].[Fact_Financials]
select top 5 * from dbo.Dim_GL_Accounts
select top 5 * from dbo.Dim_ProfitabilityMatrix
select top 5 * from dbo.Dim_Date
select * from dbo.Dim_Product
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--QUERY WITHOUT Internal CHE Allocation
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SELECT snapshot_date	
,GL.Account_Code	
--,Xero_Account_Name	
--,Xero_Account_Type
,GL.Xero_Acct_Name						
,GL.Account_Group				
,GL.Account_Type				
--,GL_TYPE	
,GL.GL_Code
,GL.GLOrder
,GL.FC_GL_CODE	
,GL.GLLevel_1	
,GL.GLLevel_2	
,GL.GLLevel_3	
,GL.GLLevel_4	
,GL.GLLevel_5	
,GL.GLLevel_6	
,GL.GLLevel_7	
,GL.GLLevel_8
,GL.GL_SPLIT
,Split
,GL.weight
,Product_Name
,(Split*isnull(Actual_Debit_MTD		,0)) as Actual_Debit_MTD	
,(Split*isnull(Actual_Credit_MTD	,0)) as Actual_Credit_MTD	
,(Split*isnull(Actual_Balance_MTD	,0)) as Actual_Balance_MTD	
,(Split*isnull(Actual_Debit_YTD		,0)) as Actual_Debit_YTD	
,(Split*isnull(Actual_Credit_YTD	,0)) as Actual_Credit_YTD	
,(Split*isnull(Actual_Balance_YTD	,0)) as Actual_Balance_YTD	
,(Split/**GL_Weight*/*isnull(Budget_MTD,0)) as Budget_MTD	
,(Split/**GL_Weight*/*isnull(Budget_YTD,0)) as Budget_YTD
FROM [dbo].[Fact_Financials] F
LEFT JOIN dbo.Dim_GL_Accounts GL
	ON GL.Account_Code=F.Account_Code
LEFT JOIN dbo.Dim_ProfitabilityMatrix  M 
	ON M.SplitType=GL.GL_SPLIT
where 1=1
and GL.Account_Group='Profit Loss'
--and GL.GLLevel_1<>'Balance Sheet'
--and GL_Code='GWP'
--and FC_GL_CODE='OI'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--QUERY INCLUDING Internal CHE Allocation
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--1) Original GL_Code
select  
	F.snapshot_date
	,GL.Account_Code
	,GL.Xero_Acct_Name						
	,GL.Account_Group				
	,GL.Account_Type				
	--,GL_TYPE	
	,GL.GL_Code
	,GL.GLOrder
	,GL.FC_GL_CODE	
	,GL.GLLevel_1	
	,GL.GLLevel_2	
	,GL.GLLevel_3	
	,GL.GLLevel_4	
	,GL.GLLevel_5	
	,GL.GLLevel_6	
	,GL.GLLevel_7	
	,GL.GLLevel_8
	,GL.GL_SPLIT
	,Split
	,GL.weight
	,P.Product_Name
	,Product_group_code	
	,P.ProductGroup
	,M.SplitType
	,M.Split
	,isnull(1.0-SM.SM_Split,1.0) as SM_Split
	,(Split*isnull(Actual_Debit_MTD		,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Debit_MTD	
	,(Split*isnull(Actual_Credit_MTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Credit_MTD	
	,(Split*isnull(Actual_Balance_MTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Balance_MTD	
	,(Split*isnull(Actual_Debit_YTD		,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Debit_YTD	
	,(Split*isnull(Actual_Credit_YTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Credit_YTD	
	,(Split*isnull(Actual_Balance_YTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Balance_YTD	
	,(Split/**GL_Weight*/*isnull(Budget_MTD,0))	* isnull(1.0-SM_Split,1.0)	as Budget_MTD	
	,(Split/**GL_Weight*/*isnull(Budget_YTD,0))	* isnull(1.0-SM_Split,1.0)	as Budget_YTD
from [dbo].[Fact_Financials]					F
	left join [dbo].[Dim_GL_Accounts]			GL	on GL.Account_Code=F.Account_Code
	left join [dbo].[Dim_ProfitabilityMatrix]	M	on M.SplitType=GL.GL_Split
	left join [dbo].[Dim_Product]				P	on P.Product_id=M.Product_id
	left join [dbo].[Dim_Strawman]				SM  on SM.Account_Code=F.Account_Code
where 1=1
	--and GL.GLLevel_8<>'Balance Sheet'
	and GL.Account_Group='Profit Loss'
	--and F.Account_Code in ('30103') and F.snapshot_date=20200430
UNION 
--2) Reallocation of Internal Claim Handling Expanses
select  
	F.snapshot_date
	,GL.Account_Code
	,GL.Xero_Acct_Name						
	,GL.Account_Group				
	,GL.Account_Type				
	--,GL_TYPE	
	,isnull(SM.GL_Code_SM,GL.GL_Code) as GL_Code
	,GL.GLOrder
	,GL.FC_GL_CODE	
	,GL.GLLevel_1	
	,GL.GLLevel_2	
	,GL.GLLevel_3	
	,GL.GLLevel_4	
	,GL.GLLevel_5	
	,GL.GLLevel_6	
	,GL.GLLevel_7	
	,GL.GLLevel_8
	,GL.GL_SPLIT
	,Split
	,GL.weight
	,P.Product_Name
	,Product_group_code	
	,P.ProductGroup
	,M.SplitType
	,M.Split
	,isnull(SM.SM_Split,1) as SM_Split
	,(Split*isnull(Actual_Debit_MTD		,0))	* SM_Split	as Actual_Debit_MTD	
	,(Split*isnull(Actual_Credit_MTD	,0))	* SM_Split	as Actual_Credit_MTD	
	,(Split*isnull(Actual_Balance_MTD	,0))	* SM_Split	as Actual_Balance_MTD	
	,(Split*isnull(Actual_Debit_YTD		,0))	* SM_Split	as Actual_Debit_YTD	
	,(Split*isnull(Actual_Credit_YTD	,0))	* SM_Split	as Actual_Credit_YTD	
	,(Split*isnull(Actual_Balance_YTD	,0))	* SM_Split	as Actual_Balance_YTD	
	,(Split/**GL_Weight*/*isnull(Budget_MTD,0))	* SM_Split	as Budget_MTD	
	,(Split/**GL_Weight*/*isnull(Budget_YTD,0))	* SM_Split	as Budget_YTD
from [dbo].[Fact_Financials]					F
	left join [dbo].[Dim_GL_Accounts]			GL	on GL.Account_Code=F.Account_Code
	left join [dbo].[Dim_ProfitabilityMatrix]	M	on M.SplitType=GL.GL_Split
	left join [dbo].[Dim_Product]				P	on P.Product_id=M.Product_id
	inner join [dbo].[Dim_Strawman]				SM  on SM.Account_Code=F.Account_Code
where 1=1
	--and GL.GLLevel_8<>'Balance Sheet'
	and GL.Account_Group='Profit Loss'
	--and F.snapshot_date=@SNAP
	--and F.Account_Code in ('30002','30103')
	--and F.Account_Code in ('30103') and F.snapshot_date=20200430


/*

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where GLLevel_1<>'Balance Sheet'
and GL_Code='GWP'

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where GLLevel_1<>'Balance Sheet'
and FC_GL_CODE='OI'

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where Xero_Account_Type='Other Income'
and Xero_Account_Name like '%recoveries%'

select * 
from dbo.Dim_GL_Accounts
where Xero_Account_Type='Other Income'
and Xero_Account_Name like '%recoveries%'
*/

