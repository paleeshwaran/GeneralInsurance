DECLARE 
	@report_date		datetime	= '2020-09-30',
	@commission_rate	float		= 0.12

IF OBJECT_ID('tempdb..#TABLES') IS NOT NULL
    DROP TABLE #Carminder_commission_dealergroup

select 
policy_number
,p.id									as policy_id
,p.dealer_id						
,d.company_name							as policy_dealer_name	
--dealer group
,p.first_name_1							as policy_first_name_1
,p.last_name_1							as policy_last_name_1
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end as policy_product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end as policy_cover_type
,p.status										as policy_status
,p.invoiced_timestamp							as policy_invoiced_timestamp	
,p.purchase_timestamp							as policy_purchase_timestamp	
,p.from_timestamp								as policy_from_timestamp	
,p.to_timestamp									as policy_to_timestamp	
,p.payment_freq									as payment_frequency
,p.term											as policy_term	 
,p.premium										as policy_premium 
,round((p.premium/p.term)*@commission_rate,4)	as Raw_Commision
--,p.*
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
and ct.id in (3,4) --filter for Carminder product only
and (from_timestamp<=@report_date and to_timestamp>@report_date)
--and p.policy_number='50009614-9'
order by p.policy_number desc
