/*
select top 10 * from san_posm2.dealer
select top 10 * from san_posm2.vehicle
select top 10 * from san_posm2.customer

select top 10 * from san_posm2.posm_cover_type
select top 10 * from san_posm2.posm_cover_type_dealer
--select top 10 * from san_posm2.posm_dealer_brand_vehicles
select top 10 * from san_posm2.posm_policy order by id desc
select top 10 * from san_posm2.posm_policy_types
--select top 10 * from san_posm2.posm_policy_drivers
select top 10 * from [san_posm2].[insurance_product] --only important for MBI products
*/

select 
p.id					as policy_id
	,p.policy_id_parent
	,p.policy_id_child
	,p.policy_number
	,p.status
,p.dealer_id
	,d.company_name		as dealer_name
,p.customer_id
	,c.type				as customer_type
	,case 
		when c.type='individual'	then c.title_1+' '+c.first_name_1+' '+c.last_name_1
		when c.type='company'		then c.company_name
		else null end	as Customer_FullName
,p.insurance_product_id
	,ip.product_name
	,ip.product_type
,p.cover_type_id
	,p.cover_type_name
	,ct.title
,p.vehicle_id
	,v.make	
	,v.model_family	
	,v.year	
	,v.registration_plate	
	,v.vin	
	,v.stock_number
,p.*
from san_posm2.posm_policy			p
left join san_posm2.dealer			d		on d.id=p.dealer_id
left join san_posm2.customer		c		on c.id=p.customer_id
left join san_posm2.vehicle			v		on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct		on ct.id=p.cover_type_id	
left join san_posm2.insurance_product ip	on ip.id=p.insurance_product_id
where 1=1
--and p.id in (
--	5106305,5106304,5106303 --main policy examples 
--	,5091083,5091085		--parent policies
--	,5015561
--	)
and policy_number='50009614-9'
order by p.policy_number desc

--select top 10* from [san_posm2].[mbi_policy] order by 1 desc
select *  from san_posm2.posm_policy where policy_number='50009614-9'
select * from [san_posm2].[posm_policy_types]
select * from [san_posm2].posm_cover_type


select * from [san_posm2].dealer where company_name like '%NZCU%'
select * from [san_posm2].[dealer_group]
select * from [san_posm2].[dealer_dealer_group]
	where dealer_id in (select id from [san_posm2].dealer where company_name like '%NZCU%')
