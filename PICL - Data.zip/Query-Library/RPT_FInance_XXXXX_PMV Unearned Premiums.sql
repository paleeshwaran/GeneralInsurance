USE devsanposm_copy
GO
SET NOCOUNT ON
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
DECLARE 
	@report_date		datetime	= '2020-08-31',
	@report_start_month	datetime,
	@report_month_days	int
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SET @report_start_month =dateadd(month,-1,dateadd(day,1,@report_date))
SET @report_month_days=day(@report_date)
select 
	@report_start_month	as report_start_month
	,@report_date		as report_date
	,@report_month_days	as report_month_days

/*
select 
	@report_date			as report_date
	,@report_start_month	as report_start_month
*/
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#policies') IS NOT NULL
    DROP TABLE #policies

select 
policy_number
,p.id as policy_id
/*
,p.dealer_id	
,d.company_name										as dealer_name	
--,p.first_name_1										
--,p.last_name_1										
,p.product_name
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as policy_product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as cover_type
*/
,p.status											as policy_status
,p.payment_freq										
,p.term		
,p.premium	
,p.additional_risk_premium
,p.life_insurance_fee
------------------------------------------------------------------------------------------------------------------------------------------------------
,case when p.dealer_id=225 then 1 else 0 end as FF_Flag
,convert(date,invoiced_timestamp,23) last_invoice_date
,convert(date,case when invoiced_timestamp<@report_start_month then @report_start_month else invoiced_timestamp end,23) as period_UE_StartDate
,case when @report_date>(Case when cancelled_timestamp>to_timestamp then to_timestamp else cancelled_timestamp end) 
		then (Case when cancelled_timestamp>to_timestamp then to_timestamp else cancelled_timestamp end)
		else @report_date end as period_UE_EndDate
,convert(date,coalesce(cancelled_timestamp,auto_expired_timestamp,to_timestamp),23) as policy_end_date
,datediff(day
	,case when invoiced_timestamp<@report_start_month then @report_start_month else invoiced_timestamp end
	,case when @report_date>(Case when cancelled_timestamp>to_timestamp then to_timestamp else cancelled_timestamp end) 
		then (Case when cancelled_timestamp>to_timestamp then to_timestamp else cancelled_timestamp end)
		else @report_date end
	) as UE_days
------------------------------------------------------------------------------------------------------------------------------------------------------
,p.purchase_timestamp									
,p.invoiced_timestamp									
,p.from_timestamp									
,p.to_timestamp	
,auto_expired_timestamp --,isnull(auto_expired_timestamp	,'2999-12-31') as auto_expired_timestamp
,cancelled_timestamp	--,isnull(cancelled_timestamp		,'2999-12-31') as cancelled_timestamp		
,deactivated_timestamp	--,isnull(deactivated_timestamp	,'2999-12-31') as deactivated_timestamp
------------------------------------------------------------------------------------------------------------------------------------------------------
,case when cancelled_timestamp<@report_start_month then 1 else 0 end as Cancelled_PriorPeriod_flag
,case when cancelled_timestamp between @report_start_month and @report_date then 1 else 0 end as CancelledDuringMonth_Flag
,case when auto_expired_timestamp<@report_start_month then 1 else 0 end as Expired_PriorPeriod_Flag 
,case when auto_expired_timestamp between @report_start_month and @report_date then 1 else 0 end as ExpiredDuringMonth_Flag
------------------------------------------------------------------------------------------------------------------------------------------------------										
,premium_with_gst	
,premium_with_gst_payable
,wholesalepremium
,retail_premium_over_term	
,retail_premium_annual	
,retail_premium_monthly	
,retail_premium_fortnightly	
,retail_premium_weekly	
,wholesalepremium_over_term
--,round((p.premium/p.term)*com.Com_Rate,2)			as Commision
--,p.*
into #policies
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
--REPORT FILTERS:
	and invoiced_timestamp<=@report_date	
	--and to_timestamp>=@report_date
	--and (cancelled_timestamp<@report_start_month	
	/*--need to check business rules between status flag value and timestamps available:
		and (cancelled_timestamp	is null 
			and auto_expired_timestamp	is null 
			and deactivated_timestamp	is null)
	*/
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--TESTING FILTERS:
--and com.Carminder_Com_Flag=1	--filter for Credit Union having a commission calculated for Carminder
--and payment_freq='Y'			--search for a particular payment frequency
--and status='X'
--and to_timestamp>='2020-01-01'
--and (cancelled_timestamp is null 
--	or auto_expired_timestamp is null
	--or deactivated_timestamp is null
	--)
/*
and to_timestamp>=@report_start_month--dateadd(day,-5,@report_start_month)
and (to_timestamp between @report_start_month and @report_date
	or  auto_expired_timestamp between @report_start_month and @report_date
	or deactivated_timestamp  between @report_start_month and @report_date
	)
*/
--and to_timestamp>=@report_start_month
--and to_timestamp between @report_start_month and @report_date
--and deactivated_timestamp  between @report_start_month and @report_date
--and p.term = 12
--and (status='E' and auto_expired_timestamp>=@report_start_month)
--	or 

and p.id in (--Examples for report ending 31-08-2020
	5088486								--policy ending 07/30 but auto_expired 08/01
	,5105216							--cancelled renewal (cancellation/deactivation>policy start)
	,5090894							--cancelled during the month -- yearly
	,5092265							--cancelled during the month -- monthly
	,5092356							--cancelled during the month -- fortnightly
	,5092530							--cancelled during the month -- weekly
	,5008455,5008762,5008824,5009532	--36 months example for each period
	,5010007,5011352,5012322,5086286	--36 months Family Finance
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
order by 
	--p.policy_number desc
	p.status
	,convert(date,coalesce(cancelled_timestamp,auto_expired_timestamp),23) desc


-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#max_invoice') IS NOT NULL
    DROP TABLE #max_invoice
select 
id	
,posted_to_fms	
,fms_invoice_number	
,invoice_timestamp	
,policy_id	
,product	
,gross_premium	
,life_cover	
,gross_fsl	
,gross_fee	
,gst	
,net_total_gst_items	
,gross_total_gst_items	
,total_non_gst_items	
,rounded_payment_amount	
,xero_invoice_id	
,xero_batch_id	
,piclos_batch_id
into #max_invoice
from [san_posm2].[invoice_direct_debit]
where id in (
	select max(id) 
	from [san_posm2].[invoice_direct_debit]
	where policy_id in (select policy_id from #policies)
	and invoice_timestamp<=@report_date
	group by policy_id
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#next_invoice') IS NOT NULL
    DROP TABLE #next_invoice

select 
id	
,posted_to_fms	
,fms_invoice_number	
,invoice_timestamp	
,policy_id	
,product	
,gross_premium	
,life_cover	
,gross_fsl	
,gross_fee	
,gst	
,net_total_gst_items	
,gross_total_gst_items	
,total_non_gst_items	
,rounded_payment_amount	
,xero_invoice_id	
,xero_batch_id	
,piclos_batch_id
into #next_invoice
from [san_posm2].[invoice_direct_debit]
where id in (
	select min(id) 
	from [san_posm2].[invoice_direct_debit]
	where policy_id in (select policy_id from #policies)
	and invoice_timestamp>@report_date
	group by policy_id
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#invoices') IS NOT NULL
    DROP TABLE #invoices

select policy_id
	,max(last_invoice) as last_invoice
	,max(next_invoice) as next_invoice
into #invoices 
from (
	select m.policy_id
	,invoice_timestamp		as last_invoice
	,null					as next_invoice
	from #max_invoice m 
	union
	select m.policy_id
	,null					as last_invoice
	,invoice_timestamp		as next_invoice
	from #max_invoice m 
	)X
group by policy_id
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

select 
p.policy_number
,p.policy_id
,policy_status
,FF_Flag
,payment_freq	
,term	
,from_timestamp	
,to_timestamp
,i.last_invoice
,i.next_invoice
,p.premium	
,p.additional_risk_premium
,p.life_insurance_fee	
,last_invoice_date	
,period_UE_StartDate	
,period_UE_EndDate	
,policy_end_date	
,UE_days	
,purchase_timestamp	
,invoiced_timestamp	
from #policies p
left join #invoices i on i.policy_id=p.policy_id


select 
	policy_number	
	,policy_id	
	,policy_status	
	,payment_freq	
	,term 
	,FF_Flag
	,p.invoiced_timestamp									
	,p.from_timestamp									
	,p.to_timestamp	
	,premium
	,additional_risk_premium
	,life_insurance_fee
	,retail_premium_annual	
	,retail_premium_monthly	
	,retail_premium_fortnightly	
	,retail_premium_weekly	
from #policies p
where policy_id in (5086286,5009532)

select policy_id
	,count(*)			as instalments
	,avg(gross_premium) as period_premium
	,sum(gross_premium) as total_premium
	,sum(life_cover)	as total_life_cover	
	,sum(gross_fsl)		as total_gross_fsl
	,sum(gross_fee)		as total_gross_fee
	,sum(gst)			as total_gst
	,sum(rounded_payment_amount) as total_payments
from [san_posm2].[invoice_direct_debit]
where policy_id in (5086286,5009532)
group by policy_id

select *
from [san_posm2].[invoice_direct_debit]
where policy_id in (5086286/*,5009532*/)
/*
where id in (
	select max(id) 
	from [san_posm2].[invoice_direct_debit]
	where policy_id in (5086286,5009532)
	and invoice_timestamp<=@report_date
	group by policy_id
	)
*/
  SELECT 
	inp.invoice_id 
	,i.fms_invoice_number
	,inp.policy_id
	,policy_description
	,i.created_date
	,inp.invoice_year		
	,i.total
	,inp.gst_rate
	,i.gst	total
  FROM [san_posm2].[invoice_policy] inp
  LEFT JOIN [san_posm2].[invoice] i on i.id=inp.invoice_id
  WHERE policy_id=5009532

  select 
  wholesalepremium_over_term/term
  ,* from #policies where policy_id=5086286