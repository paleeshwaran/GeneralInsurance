CREATE PROCEDURE dbo.LoadReconciliationFiles
AS
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--CREATE TABLES
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('dbo.Load_Integral_Files', 'U') IS NOT NULL 
	DROP TABLE  dbo.Load_Integral_Files 
CREATE TABLE dbo.Load_Integral_Files 
	(
	IntegralFileName	varchar(100)	NOT NULL
	,FileType			varchar(10)		NULL
	,FileExtension		varchar(10)		NULL
	,Date_accessed		datetime		NULL
	,Date_modified		datetime		NULL
	,Date_created		datetime		NULL
	)

IF OBJECT_ID('dbo.Load_Integral_Claims', 'U') IS NOT NULL 
	DROP TABLE  dbo.Load_Integral_Claims 
CREATE TABLE dbo.Load_Integral_Claims 
	(
	IntegralFileName	varchar(100)	NOT NULL
	,Date_created		datetime		NULL
	,update_type		varchar(25)		NULL
	,claim_unid			varchar(100)	NOT NULL
	,created_date		datetime		NULL
	,excess				float			NULL
	,file_no			varchar(25)		NULL
	,claim_status		varchar(25)		NULL
	,claim_sub_status	varchar(100)	NULL
	,fault				varchar(100)	NULL
	,policy_number		varchar(25)		NULL
	,incident_type		varchar(25)		NULL
	,declined_date		datetime		NULL
	,total_estimate		float			NULL
	,is_accepted		varchar(25)		NULL
	,recovery_status	varchar(100)	NULL
	,date_of_loss		datetime		NULL
	)

IF OBJECT_ID('dbo.Load_Integral_Payments', 'U') IS NOT NULL 
	DROP TABLE  dbo.Load_Integral_Payments
CREATE TABLE dbo.Load_Integral_Payments 
	(
	IntegralFileName	varchar(100)	NOT NULL
	,Date_created		datetime		NULL
	,update_type		varchar(25)		NULL
	,claim_unid			varchar(100)	NOT NULL
	,created_date		datetime		NULL
	,excess				float			NULL
	,payment_item_id	varchar(6)		NOT NULL
	,status				varchar(1)		NULL
	,paid_timestamp		datetime		NULL
	,payee_name			varchar(250)	NULL
	,gst				float			NULL
	,total				float			NULL
	,deduct_excess		varchar(25)		NULL
	,category			varchar(100)	NULL
	,payment_ref		varchar(25)		NULL
	,prepared_by		varchar(50)		NULL
	,prepared_on		datetime		NULL
	,payment_locked_by	varchar(50)		NULL
	,payment_locked_on	datetime		NULL
	)

--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
IF OBJECT_ID('dbo.Load_McLarens_PVT', 'U') IS NOT NULL 
	DROP TABLE  dbo.Load_McLarens_PVT 
CREATE TABLE dbo.Load_McLarens_PVT
	(
	 Type								varchar(25)		NOT NULL
	,Change_Date						datetime		NOT NULL
	,Claim_UNID							varchar(100)	NOT NULL
	,Claim_File							varchar(25)		NULL
	,Claim_Status						varchar(25)		NULL
	,Claim_Reference					varchar(100)	NULL
	,Claim_Type							varchar(100)	NULL
	,Claim_Received						datetime		NULL
	,Claim_Date_of_Loss					datetime		NULL
	,Claim_Adjuster_Name				varchar(100)	NULL
	,Policy_Insured_Name				varchar(100)	NULL
	,Policy_Insured_Email				varchar(100)	NULL
	,Policy_Type						varchar(100)	NULL
	,Policy_Number						varchar(25)		NULL
	,Policy_Inception_Date				datetime		NULL
	,Policy_Expiry_Date					datetime		NULL
	,Cat_Code							varchar(100)	NULL
	,Cause_Code_Short					varchar(3)		NULL
	,Cause_Code							varchar(100)	NULL
	,Fault								varchar(25)		NULL
	,Repair_Total_Loss					varchar(25)		NULL
	,Third_Party						varchar(max)	NULL
	,Status_Change_Date					datetime		NULL
	,Status_Claim_Status				varchar(100)	NULL
	,Status_Sub_Status					varchar(100)	NULL
	,Status_Changed_By					varchar(100)	NULL
	,Estimate_Section					varchar(100)	NULL
	,Estimate_Section_Status			varchar(25)		NULL
	,Estimate_Sum_Insured				float			NULL
	,Estimate_Excess					float			NULL
	,Estimate_Apply_Excess				varchar(25)		NULL
	,Estimate_Change_Date				datetime		NULL
	,Estimate_End_Date					datetime		NULL
	,Estimate_Status					varchar(25)		NULL
	,Estimate_Reserve_Gross				float			NULL
	,Estimate_Reserve_Net				float			NULL
	,Estimate_Reserve_Gst				float			NULL
	,Payment_Section					varchar(100)	NULL
	,Payment_Date						datetime		NULL
	,Payment_Ref						varchar(100)	NULL
	,Payment_Title						varchar(max)	NULL
	,Payment_Status						varchar(25)		NULL
	,Payment_Type						varchar(100)	NULL
	,Payment_Payee_Name					varchar(max)	NULL
	,Payment_Payee_Email				varchar(100)	NULL
	,Payment_Payee_Bank_Account_Name	varchar(100)	NULL
	,Payment_Payee_Bank_Account			varchar(100)	NULL
	,Payment_Item_Description			varchar(max)	NULL
	,Payment_Item_Invoice_Number		varchar(max)	NULL
	,Payment_Item_Invoice_Date			datetime		NULL
	,Payment_Item_Amount_Gross			float			NULL
	,Payment_Item_Amount_Net			float			NULL
	,Payment_Item_Amount_Gst			float			NULL
	,Payment_Prepared_By				varchar(100)	NULL
	,Payment_Locked_By					varchar(100)	NULL
	,Payment_Locked_On					datetime		NULL
	,Include							varchar(25)		NULL
	)

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--INSERT DATA from csv
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
TRUNCATE TABLE dbo.Load_Integral_Files
BULK INSERT dbo.Load_Integral_Files
FROM 'C:\McLarens-Integral Files\DB Import\Integral_Files.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Load_Integral_Claims
BULK INSERT dbo.Load_Integral_Claims
FROM 'C:\McLarens-Integral Files\DB Import\Integral_Claims.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Load_Integral_Payments
BULK INSERT dbo.Load_Integral_Payments
FROM 'C:\McLarens-Integral Files\DB Import\Integral_Payments.csv'
--'C:\SharePoint\Provident Insurance\Shared Documents - Documents\IT\Datawarehouse\002-Discovery\Integrations\McLarens\Integral Integration Reconciliation\DB csv\Integral_Payments.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
TRUNCATE TABLE dbo.Load_McLarens_PVT
BULK INSERT dbo.Load_McLarens_PVT
FROM 'C:\McLarens-Integral Files\DB Import\PVT-Transactions_2021-02-28-2.csv'
--'C:\SharePoint\Provident Insurance\Shared Documents - Documents\IT\Datawarehouse\002-Discovery\Integrations\McLarens\Integral Integration Reconciliation\DB csv\PVT-Transactions_2021-02-28.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


	