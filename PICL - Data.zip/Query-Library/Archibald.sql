select --top 10
p.id as policy_id
,policy_number
,case when status='V'then 1 else 0 end as ActivePolicies
,case when d.id in (551,552,477) then 1 else 0 end as Archibald_Flag
,case when status='V'then 1 else 0 end 
	*case when d.id in (551,552,477) then 1 else 0 end as Archibald_Active
,d.id as dealer_id
,d.company_name
,p.make
,model_family
,year
,p.status
,convert(date,p.invoiced_timestamp,23) as invoiced_timestamp
--,p.purchase_timestamp
--,p.auto_expired_timestamp
--,p.cancelled_timestamp
--,p.deactivated_timestamp
--,p.refund_timestamp
,convert(date,p.from_timestamp,23) as from_timestamp
,convert(date,p.to_timestamp,23) as to_timestamp
--,p.*
from [picllivedb].[posm_policy] p
left join [picllivedb].dealer d on d.id=p.dealer_id
where 1=1
and (d.id in (551,552,477)--Dealer = Archibald & Shorter 
	or Make in ('Jaguar','Land Rover','Landrover','Volvo')
	)
--and status='V'
