/*
SELECT t.name ,c.name
from sys.tables t
join sys.columns c on c.object_id=t.object_id
where c.name like '%_key%'
*/
IF OBJECT_ID(N'tempdb..#policy_vehicle', N'U') IS NOT NULL   
DROP TABLE #policy_vehicle; 

;WITH POLICY_VEHICLES_RAW AS (
	--posm policies
	select 
	--policy identifiers
		'posm' as DataSource
		,id  as policy_id
		,policy_number
		,policy_type_id	
	--policy dates:
		,status	
		,from_timestamp	
		,to_timestamp	
		,invoiced_timestamp
		,auto_expired_timestamp	
		,cancelled_timestamp	
		,deactivated_timestamp
		,is_renewal	
		,renewal_pending
		,term
	--vehicle identifier and details:
		,vehicle_id
		,rb_vehicle_key
		--,policy_holder_licence_number
		,registration_plate		
		,vin	
		,stock_number
		,vehicle_make_id	
		,vehicle_model_id	
		,make	
		,model_family	
		,model	
		,year	
		--,cc_rating	
		--,motor_type	
		--,vehicle_type
	from [san_posm2].[posm_policy]
	--where status='V'

		union

	select top 10  
	'tar' as DataSource
	,id as policy_id
	,NULL as policy_number
	,NULL as policy_type_id
	,status
	,from_timestamp
	,to_timestamp
	,invoiced_timestamp
	,auto_expired_timestamp
	,NULL cancelled_timestamp
	,deactivated_timestamp
	,NULL as is_renewal
	,NULL as renewal_pending
	,term
	,vehicle_id
	,null as rb_vehicle_key
	,registration_plate	
	,vin	
	,stock_number	
	,NULL as vehicle_make_id
	,NULL as vehicle_model_id
	,make	
	,model_family	
	,model	
	,year
	--,odometer	
	--,date_vehicle_purchased	
	--,vehicle_usage
	--,*
	from [san_posm2].[tar_policy]

		union

	select top 10 
	'gap' as DataSource
	,id as policy_id
	,NULL as policy_number
	,NULL as policy_type_id
	,status
	,from_timestamp
	,to_timestamp
	,invoiced_timestamp
	,auto_expired_timestamp
	,NULL cancelled_timestamp
	,deactivated_timestamp
	,NULL as is_renewal
	,NULL as renewal_pending
	,term
	,vehicle_id	
	,NULL as rb_vehicle_key 
	,registration_plate	
	,vin
	,NULL as stock_number
	,null as vehicle_make_id	
	,NULL as vehicle_model_id
	,make	
	,model_family	
	,model	
	,year
	from [san_posm2].[gap_policy]
	)
SELECT
	DataSource	
	,policy_id	
	,policy_number	
	,policy_type_id	
	,status	
	,from_timestamp	
	,to_timestamp	
	,invoiced_timestamp	
	,auto_expired_timestamp	
	,cancelled_timestamp	
	,deactivated_timestamp	
	,is_renewal	
	,renewal_pending	
	,term	
	,case when isnull(vehicle_id,'')='' then 1 else  0 end as Missing_vehicle_id
	,case when isnull(vehicle_make_id,'')='' then 1 else  0 end as Missing_vehicle_make_id
	,case when isnull(vehicle_model_id,'')='' then 1 else  0 end as Missing_vehicle_model_id
	,case when isnull(rb_vehicle_key,'')='' then 1 else  0 end as Missing_rb_vehicle_key
	,case when vehicle_id			='' then NULL else vehicle_id			end as vehicle_id	
	,case when vehicle_make_id		='' then NULL else vehicle_make_id		end as vehicle_make_id	
	,case when vehicle_model_id		='' then NULL else vehicle_model_id		end as vehicle_model_id	
	,case when rb_vehicle_key		='' then NULL else rb_vehicle_key		end as rb_vehicle_key	
	,case when registration_plate	='' then NULL else registration_plate	end as registration_plate
	,case when vin					='' then NULL else vin					end as vin	
	,case when stock_number			='' then NULL else stock_number			end as stock_number	
	,case when make					='' then NULL else make					end as make						
	,case when model_family			='' then NULL else model_family			end as model_family			
	,case when model				='' then NULL else model				end as model				
	,case when year					='' then NULL else year					end as year					
	INTO #policy_vehicle
	FROM POLICY_VEHICLES_RAW

IF OBJECT_ID(N'tempdb..#vehicles', N'U') IS NOT NULL   
DROP TABLE #vehicles;  

select
id as vehicle_id
,case when oneport_id			='' then null else oneport_id			END AS oneport_id	
,case when motochek_id			='' then null else motochek_id			END AS motochek_id
,case when registration_plate	='' then null else registration_plate	END AS registration_plate
,case when stock_number			='' then null else stock_number			END AS stock_number
,case when vin					='' then null else vin					END AS vin
,case when make					='' then null else make					END AS make
,case when model_family			='' then null else model_family			END AS model_family
,case when other_model			='' then null else other_model			END AS other_model
,case when year					='' then null else year					END AS year
,case when cc_rating			='' then null else cc_rating			END AS cc_rating
INTO #vehicles
from [san_posm2].[vehicle]

--VIN Checker
select 
	'policies' as SourceTable
	,vin	
	,left(vin,1)			as VIN_Country
	,right(left(vin,3),2)	as VIN_Make
	,right(left(vin,8),5)	as VIN_Model
	,left(right(vin,5),8)	as VIN_Model
	,left(right(vin,1),10)	as VIN_Year
	,registration_plate
	,make	
	,model_family	
	,model	
	,year
from #policy_vehicle
union
select 
	'vehicles' as SourceTable
	,vin	
	,registration_plate
from #vehicles

select distinct Make,VIN_WMI
from (
	select 
		'policies' as SourceTable
		,vin	
		,left(vin,3)			as VIN_WMI
		,right(left(vin,6),3)	as VIN_Make
		,right(left(vin,8),2)	as VIN_Model
		,registration_plate
		,make	
		,model_family	
		,model	
		,year
	from #policy_vehicle
	where vin is not null
	)X
order by Make,VIN_WMI

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--vehicle join --> not working !!!
select 
DataSource
,pv.vehicle_id	
,case when v.vin					<> pv.registration_plate then 1 else 0 end as Check_registration_plate
,case when v.registration_plate		<> pv.vin				 then 1 else 0 end as Check_vin				
,case when v.stock_number			<> pv.stock_number		 then 1 else 0 end as Check_stock_number		
,case when v.make					<> pv.make				 then 1 else 0 end as Check_make				
,case when v.model_family			<> pv.model_family		 then 1 else 0 end as Check_model_family		
,case when v.other_model			<> pv.model				 then 1 else 0 end as Check_other_model		
,case when v.year					<> convert(varchar,pv.year) then 1 else 0 end as Check_year	
--policy table data
,pv.vehicle_make_id	
,pv.vehicle_model_id	
,pv.rb_vehicle_key	
,pv.registration_plate	
,pv.vin	
,pv.stock_number	
,pv.make	
,pv.model_family	
,pv.model	
,pv.year
--vehicle table data
,v.registration_plate	
,v.vin	
,v.stock_number	
,v.make	
,v.model_family	
,v.other_model	
,v.year			
from #policy_vehicle pv
left join #vehicles v on v.vehicle_id=pv.vehicle_id
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--Vehicles in policy table with Redbook key
IF OBJECT_ID(N'tempdb..#RB_match', N'U') IS NOT NULL   
DROP TABLE #RB_match;  
select distinct
rb_vehicle_key	
,pv.make	
,pv.model_family	
,pv.model	
,pv.year
,rb.SequenceNum	
,rb.MakeCode	
,rb.FamilyCode	
,rb.YearGroup	
,rb.Description
into #RB_match
from #policy_vehicle pv
left join [san_posm2].[rb_vehicle] rb
	on rb.VehicleKey=pv.rb_vehicle_key
where rb_vehicle_key is not null
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--MAKES
select distinct
	make	
	,MakeCode	
	,case when make<>MakeCode	then 1 else 0 end as Make_mismatch
from #RB_match
order by 
	MakeCode	

select distinct make,model_family
from #policy_vehicle
where 1=1
and isnull(make,'')<>''
and isnull(model_family,'')<>''
--and rb_vehicle_key is null

select distinct MakeCode,familyCode
from [san_posm2].[rb_vehicle]
order by 1,2

--Model Families
select 
make	
,MakeCode	
,model_family
,FamilyCode
from #RB_match
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


select 
registration_plate	
,make	
,model_family	
,model	
,year
from #policy_vehicle
where Make in(
	--'Datsun',
	--'Fleet',
	'Hino',
	'Morris')
order by make,model_family,model,year desc



select 
pv.status
,pv.registration_plate
,pv.vin
,pv.stock_number
,rb_vehicle_key	
,pv.make	
,pv.model_family	
,pv.model	
,pv.year
,rb.SequenceNum	
,rb.MakeCode	
,rb.FamilyCode	
,rb.YearGroup	
,rb.Description
,pv.*
from #policy_vehicle pv
left join [san_posm2].[rb_vehicle] rb
	on rb.VehicleKey=pv.rb_vehicle_key
where 1=1
and pv.status='V' and registration_plate='DWQ960'
--and Make='Nissan'	
--and MakeCode='FORD'

select * 
from [san_posm2].[posm_policy]
--where registration_plate='DWQ960'
where rb_vehicle_key='NZVMITS2010AECD'


select distinct
	make	
	,MakeCode	
	,model_family	
	,FamilyCode
	,year
	,YearGroup
	--,pv.model	
	--,Description
	--,SequenceNum	
from #RB_match
order by 
	make	
	,model_family	
	,year
--where rb_vehicle_key is not null
/*
--find duplicate plates:
select * 
from POLICY_VEHICLES
where registration_plate in (
	select registration_plate
	from POLICY_VEHICLES
	group by registration_plate
	having count(*)>1
	)
order by registration_plate

--find vehicle with missing vehicle_id
select 
DataSource,status,Missing_vehicle_id
,count(*)
from policy_vehicle
group by DataSource,status,Missing_vehicle_id
*/



/*
select top 10
'lnm' as DataSource
,id	
,vehicle_id
from [san_posm2].[lnm_policy]
where vehicle_id<>0

select top 10 * from [san_posm2].[invoice_vehicle]
*/
--vehicle tables


/*
select * from [san_posm2].[vehicle]
select * from [san_posm2].[vehicle_category]
select * from [san_posm2].[vehicle_category_mapping]
select * from [san_posm2].[vehicle_modification]
select * from [san_posm2].[vehicle_policies]

--Redbook Data
select * from [san_posm2].[rb_vehicle]
select * from [san_posm2].[rb_make]
select * from [san_posm2].[rb_family]
select * from [san_posm2].[rb_year]
select * from [san_posm2].[redbook_vehicle]
--select * from [san_posm2].[rb_log]
*/