  SELECT
  p.id as policy_id
  ,p.policy_number
  ,p.purchase_timestamp									
	,p.invoiced_timestamp									
	,p.from_timestamp									
	,p.to_timestamp	
	,auto_expired_timestamp --,isnull(auto_expired_timestamp	,'2999-12-31') as auto_expired_timestamp
	,cancelled_timestamp	--,isnull(cancelled_timestamp		,'2999-12-31') as cancelled_timestamp		
	,deactivated_timestamp	--,isnull(deactivated_timestamp	,'2999-12-31') as deactivated_timestamp			
  ,p.status
  ,payment_freq
  ,p.term
  ,p.payment_type
  ,p.refund
  ,i.*
  --,'TOTO' as Separator1   ,p.*
  FROM [picllivedb].[invoice_policy] inp
  LEFT JOIN [picllivedb].[invoice] i on i.id=inp.invoice_id
  LEFT JOIN [picllivedb].[posm_policy] p on p.id=inp.policy_id
  WHERE 1=1
  AND to_timestamp>='2020-01-31'
  AND payment_freq in ('M','F','W')
  AND p.cancelled_timestamp between '2020-08-01' and '2020-10-31'


SELECT 
idd.id	 as invoice_id
,policy_id
,p.policy_number
	  ,p.purchase_timestamp									
		,p.invoiced_timestamp									
		,p.from_timestamp									
		,p.to_timestamp	
		,auto_expired_timestamp --,isnull(auto_expired_timestamp	,'2999-12-31') as auto_expired_timestamp
		,cancelled_timestamp	--,isnull(cancelled_timestamp		,'2999-12-31') as cancelled_timestamp		
		,deactivated_timestamp	--,isnull(deactivated_timestamp	,'2999-12-31') as deactivated_timestamp			
	  ,p.status
	  ,payment_freq
	  ,p.term
	  ,p.payment_type
	  ,p.refund
,posted_to_fms	
,fms_invoice_number	
,invoice_timestamp	
,policy_id	
,product	
,gross_premium	
,life_cover	
,gross_fsl	
,gross_fee	
,idd.gst	
,net_total_gst_items	
,gross_total_gst_items	
,total_non_gst_items	
,rounded_payment_amount	
,xero_invoice_id	
,xero_batch_id	
,piclos_batch_id
,idd.*
FROM [picllivedb].[invoice_direct_debit] idd
LEFT JOIN [picllivedb].[posm_policy] p on p.id=idd.policy_id
WHERE 1=1
and p.id=5090299
/*and p.id in (
	5085218,
	5093431,
	5081756,
	5092139,
	5090299
	)*/
--order by idd.policy_id,invoice_timestamp

select * 
from [picllivedb].direct_debit
where policy_id in (5085218,5090299)

select * 
from [picllivedb].archive_direct_debit
where policy_id in (5085218,5090299)
/*
select policy_id ,term,count(*)
from (
	select
	  policy_id
	  ,p.policy_number
	  ,p.purchase_timestamp									
		,p.invoiced_timestamp									
		,p.from_timestamp									
		,p.to_timestamp	
		,auto_expired_timestamp --,isnull(auto_expired_timestamp	,'2999-12-31') as auto_expired_timestamp
		,cancelled_timestamp	--,isnull(cancelled_timestamp		,'2999-12-31') as cancelled_timestamp		
		,deactivated_timestamp	--,isnull(deactivated_timestamp	,'2999-12-31') as deactivated_timestamp			
	  ,p.status
	  ,payment_freq
	  ,p.term
	  ,p.payment_type
	  ,p.refund
	  ,idd.id as invoice_id
	from [picllivedb].[invoice_direct_debit] idd
	left join [picllivedb].[posm_policy] p on p.id=idd.policy_id
	  WHERE 1=1
	  AND to_timestamp>='2020-01-31'
	  AND  payment_freq='M'
	  --AND payment_freq in ('M','F','W')
	  )X
group by policy_id,term
having count(*)>term
order by 2,3 desc
*/

select top 1 *
from [picllivedb].posm_claim

select * from [picllivedb].[deactivate_request] where id=20495
select * from [picllivedb].[xero_refund] where request_id=20495

--Claims Data
select * from [picllivedb].[posm_claim_stage]
select * from [picllivedb].[posm_claim_incident_type]
select * from [picllivedb].[posm_claim_recovery_status]
select * from [picllivedb].[posm_claim_declined_reason]
--Claims Payment
select * from [picllivedb].[posm_sub_claim]

--Questions and Answers
select * from [picllivedb].[posm_claim_question]
select * from [picllivedb].[posm_claim_question_category]
select * from [picllivedb].[posm_claim_question_incident_type]
select * from [picllivedb].[posm_claim_answer]