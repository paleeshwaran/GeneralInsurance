DECLARE 
	@Reporting_start	datetime = '2020-04-01'

select top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'GAP' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
--,cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
/*,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
*/
,p.term
,refund
,dealer_retail_premium 
,p.premium 
,0 as additional_risk_premium
,0 as life_insurance_fee
,0 as roadside_assist
,0 as excess
,gap_amount
,special_benefits
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
,p.*
from [picllivedb].[gap_policy] p
left join [picllivedb].gap_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=p.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start


select top 100 
id as policy_id
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,null as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,term
,refund
,premium	
,dealer_retail_premium	
,gap_amount	
,special_benefits	
,sum_insured	
,amount_financed	
,balance_payable	
,finance_from_timestamp	
,finance_term
,*
from [picllivedb].[gap_policy] p


select distinct product_type
from [picllivedb].[invoice_policy]

select distinct product
from [picllivedb].[invoice_direct_debit]

select * 
from  [picllivedb].[invoice_policy]
where product_type='GAP'

select top 5 * from [picllivedb].[invoice_policy]			order by 1 desc
select top 5 * from [picllivedb].[invoice]					order by 1 desc
select top 5 * from [picllivedb].[invoice_direct_debit]		order by 1 desc
select top 5 * from [picllivedb].[invoice_motorcover]		order by 1 desc

select id,status,premium, underwriting_premium,*
from picllivedb.cci_policy
where 1=1
and underwriting_premium<>0.00
order by 1 desc


select *  
from [picllivedb].[mbi_policy] p where premium_funded<>0
order by 1 desc
