USE Profitablity_test
GO
/*
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--VARIABLES:
DECLARE 
	@PATH varchar(max)
		
SET @PATH='C:\Finance\Profitability_Analysis\SQL\Load_Files\'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--CREATE TABLES
drop table Fact_Financials
CREATE TABLE Fact_Financials
	(
	snapshot_date			int,
	Account_Code			varchar(20),
	Actual_Debit_MTD 	 	float,
	Actual_Credit_MTD 	 	float,
	Actual_Balance_MTD 		float,
	Actual_Debit_YTD 	 	float,
	Actual_Credit_YTD 	 	float,
	Actual_Balance_YTD 	 	float,
	Budget_MTD 	 			float,
	Budget_YTD 	 			float,
	)
drop table Dim_GL_Accounts
create table Dim_GL_Accounts
/*	(
	Account_Code		varchar(20),
	Xero_Account_Name	varchar(250),
	Xero_Account_Type	varchar(250),
	GL_SPLIT			varchar(20),
	GL_TYPE				varchar(20),
	GL_Code				varchar(20),
	GLOrder				varchar(20),
	FC_GL_CODE			varchar(20),
	GLLevel_1			varchar(250),
	GLLevel_2			varchar(250),
	GLLevel_3			varchar(250),
	GLLevel_4			varchar(250),
	GLLevel_5			varchar(250),
	GLLevel_6			varchar(250),
	GLLevel_7			varchar(250),
	GLLevel_8			varchar(250),
	GL_Weight			int
	)
*/
	(
	Account_Code				varchar(20)
	,Weight						int
	,GL_Code					varchar(20)
	,GL_Split					varchar(20)
	,FC_GL_Code					varchar(20)
	,GLOrder					varchar(20)
	,Xero_Acct_Name				varchar(250)
	,Xero_Acct_Description		varchar(max)
	,Account_Group_Code			varchar(250)
	,Account_Group				varchar(250)
	,Account_Type				varchar(250)
	,Xero_Tax_Class				varchar(250)
	,GLLevel_1					varchar(250)
	,GLLevel_2					varchar(250)
	,GLLevel_3					varchar(250)
	,GLLevel_4					varchar(250)
	,GLLevel_5					varchar(250)
	,GLLevel_6					varchar(250)
	,GLLevel_7					varchar(250)
	,GLLevel_8					varchar(250)
	)

create table Dim_ProfitabilityMatrix
	(
	SplitType		varchar(20),
	Product_id		int,
	Product_name	varchar(250),
	Split			float
	)

create table Dim_Date
	(
	Snapshot_date			int,
	Calendar_date			datetime,
	Financial_year			varchar(4),
	Financial_year_num		int,
	Financial_month_num		int
	)

CREATE TABLE Dim_Strawman
	(
	Account_Code	varchar(20)	NOT NULL,
	GL_Code_SM		varchar(20),
	SM_Split		float
	)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

--BULK INSERT DATA
TRUNCATE TABLE [dbo].[Fact_Financials]
BULK INSERT [dbo].[Fact_Financials]
FROM 'C:\Finance\Profitability_Analysis\SQL\Load_Files\DATA.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_GL_Accounts
BULK INSERT dbo.Dim_GL_Accounts
FROM 'C:\Finance\Profitability_Analysis\SQL\Load_Files\Dim_GL_Account.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_ProfitabilityMatrix 
BULK INSERT dbo.Dim_ProfitabilityMatrix
FROM 'C:\Finance\Profitability_Analysis\SQL\Load_Files\Dim_ProfitabilityMatrix.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Date
BULK INSERT dbo.Dim_Date
FROM 'C:\Finance\Profitability_Analysis\SQL\Load_Files\Dim_Date.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');

TRUNCATE TABLE dbo.Dim_Strawman
BULK INSERT dbo.Dim_Strawman
FROM 'C:\Finance\Profitability_Analysis\SQL\Load_Files\Dim_Strawman.csv'
WITH ( FIRSTROW=2, FORMAT='CSV');
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
/*
select * from dbo.Fact_Financials
select * from dbo.Dim_GL_Accounts
select * from dbo.Dim_ProfitabilityMatrix  
*/
select top 5 * from [dbo].[Fact_Financials]
select top 5 * from dbo.Dim_GL_Accounts
select top 5 * from dbo.Dim_ProfitabilityMatrix
select top 5 * from dbo.Dim_Date

SELECT snapshot_date	
,GL.Account_Code	
--,Xero_Account_Name	
--,Xero_Account_Type
,Xero_Acct_Name						
,Account_Group				
,Account_Type				
--,GL_TYPE	
,GL_Code
,GLOrder
,FC_GL_CODE	
,GLLevel_1	
,GLLevel_2	
,GLLevel_3	
,GLLevel_4	
,GLLevel_5	
,GLLevel_6	
,GLLevel_7	
,GLLevel_8
,GL.GL_SPLIT
,Split
,weight
,Product_Name
,(Split*isnull(Actual_Debit_MTD		,0)) as Actual_Debit_MTD	
,(Split*isnull(Actual_Credit_MTD	,0)) as Actual_Credit_MTD	
,(Split*isnull(Actual_Balance_MTD	,0)) as Actual_Balance_MTD	
,(Split*isnull(Actual_Debit_YTD		,0)) as Actual_Debit_YTD	
,(Split*isnull(Actual_Credit_YTD	,0)) as Actual_Credit_YTD	
,(Split*isnull(Actual_Balance_YTD	,0)) as Actual_Balance_YTD	
,(Split/**GL_Weight*/*isnull(Budget_MTD,0)) as Budget_MTD	
,(Split/**GL_Weight*/*isnull(Budget_YTD,0)) as Budget_YTD
FROM [dbo].[Fact_Financials] F
LEFT JOIN dbo.Dim_GL_Accounts GL
	ON GL.Account_Code=F.Account_Code
LEFT JOIN dbo.Dim_ProfitabilityMatrix  M 
	ON M.SplitType=GL.GL_SPLIT
where GLLevel_1<>'Balance Sheet'
--and GL_Code='GWP'
--and FC_GL_CODE='OI'

--1) Original GL_Code
select  
	'Original' as Source_data
	,F.snapshot_date
	,GL.Account_Code
	,GL_Code
	,M.SplitType
	,M.Split
	,isnull(1.0-SM.SM_Split,1.0) as SM_Split
	,(Split*isnull(Actual_Debit_MTD		,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Debit_MTD	
	,(Split*isnull(Actual_Credit_MTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Credit_MTD	
	,(Split*isnull(Actual_Balance_MTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Balance_MTD	
	,(Split*isnull(Actual_Debit_YTD		,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Debit_YTD	
	,(Split*isnull(Actual_Credit_YTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Credit_YTD	
	,(Split*isnull(Actual_Balance_YTD	,0))	* isnull(1.0-SM_Split,1.0)	as Actual_Balance_YTD	
	,(Split/**GL_Weight*/*isnull(Budget_MTD,0))	* isnull(1.0-SM_Split,1.0)	as Budget_MTD	
	,(Split/**GL_Weight*/*isnull(Budget_YTD,0))	* isnull(1.0-SM_Split,1.0)	as Budget_YTD
from [dbo].[Fact_Financials]					F
	left join [dbo].[Dim_GL_Accounts]			GL	on GL.Account_Code=F.Account_Code
	left join [dbo].[Dim_ProfitabilityMatrix]	M	on M.SplitType=GL.GL_Split
	left join [dbo].[Dim_Strawman]				SM  on SM.Account_Code=F.Account_Code
where 1=1
UNION 
--2) Reallocation of Internal Claim Handling Expanses
select  
	'CHE-I' as Source_data
	,F.snapshot_date
	,GL.Account_Code
	,SM.GL_Code_SM	
	,M.SplitType
	,M.Split
	,isnull(SM.SM_Split,1) as SM_Split
	,(Split*isnull(Actual_Debit_MTD		,0))	* SM_Split	as Actual_Debit_MTD	
	,(Split*isnull(Actual_Credit_MTD	,0))	* SM_Split	as Actual_Credit_MTD	
	,(Split*isnull(Actual_Balance_MTD	,0))	* SM_Split	as Actual_Balance_MTD	
	,(Split*isnull(Actual_Debit_YTD		,0))	* SM_Split	as Actual_Debit_YTD	
	,(Split*isnull(Actual_Credit_YTD	,0))	* SM_Split	as Actual_Credit_YTD	
	,(Split*isnull(Actual_Balance_YTD	,0))	* SM_Split	as Actual_Balance_YTD	
	,(Split/**GL_Weight*/*isnull(Budget_MTD,0))	* SM_Split	as Budget_MTD	
	,(Split/**GL_Weight*/*isnull(Budget_YTD,0))	* SM_Split	as Budget_YTD
from [dbo].[Fact_Financials]					F
	left join [dbo].[Dim_GL_Accounts]			GL	on GL.Account_Code=F.Account_Code
	left join [dbo].[Dim_ProfitabilityMatrix]	M	on M.SplitType=GL.GL_Split
	inner join [dbo].[Dim_Strawman]				SM  on SM.Account_Code=F.Account_Code
where 1=1
	--and F.snapshot_date=@SNAP
	--and F.Account_Code in ('30002','30103')
	--and F.Account_Code in ('30103')
order by 3,4,1 desc
/*

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where GLLevel_1<>'Balance Sheet'
and GL_Code='GWP'

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where GLLevel_1<>'Balance Sheet'
and FC_GL_CODE='OI'

UPDATE dbo.Dim_GL_Accounts
SET GL_Weight=1
where Xero_Account_Type='Other Income'
and Xero_Account_Name like '%recoveries%'

select * 
from dbo.Dim_GL_Accounts
where Xero_Account_Type='Other Income'
and Xero_Account_Name like '%recoveries%'
*/

