select top 10
p.id
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,null as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))		--term after cancellation
	/datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--original term
	as term_prorata
,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
,p.term
,refund
,dealer_retail_premium as wholesalepremium	
,p.premium + p.roadside_assist as premium
,round(p.premium + p.roadside_assist
	*datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--term after cancellation
	/datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--original term
	,2) as premium_prorata
,*
from [picllivedb].[mbi_policy] p
left join [picllivedb].mbi_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
and invoiced_timestamp>='2019-04-01'
--and p.status='x'
--and p.id=9125823
and p.premium_funded=1
and premium<>p.dealer_retail_premium
--and invoiced_timestamp is null and purchase_timestamp>='2020-12-01'
--and from_timestamp=to_timestamp
order by 1 desc

select --top 1000 
p.id 
,ip.product_type
,ip.product_name
,ct.title as cover_type
,p.premium_funded
,is_roadside_assist
,status
,contract_date
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,null as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,term
,original_premium	
,premium
,dealer_retail_premium
,dealer_incentive
,commission_type
,commission_total
,payment_instalment	
,payment_frequency	
,payment_number_of_payments	
,payment_number_of_months	
,payment_total_amount
,p.roadside_assist 	
,ct.roadside_assist
,refund
,original_excess	
,excess
,original_claim_limit
,claim_limit
from [picllivedb].[mbi_policy] p
left join [picllivedb].mbi_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
--and payment_frequency<>'N/A'
and purchase_timestamp>='2019-04-01'
--and payment_number_of_months<>term
order by 1 desc

--Motor Cover Only:
select 
policy_id
,debitsuccess_id	
,author_id	
,processed_date	
,initial_schedule_start_date	
,initial_schedule_instalment	
,recurring_schedule_start_date	
,recurring_schedule_instalment	
,recurring_schedule_frequency	
,recurring_schedule_number_of_payments	
,recurring_schedule_number_of_months	
,recurring_schedule_total_amount
,payment_type
from [picllivedb].[mbi_premium_funded] pf
left join  [picllivedb].[mbi_policy] p on p.id=pf.policy_id

select distinct 
term
,premium_funded
--,payment_instalment	
,payment_frequency	
,payment_number_of_payments	
,payment_number_of_months
,count(*)
from [picllivedb].[mbi_policy] p
where 1=1
and purchase_timestamp>='2019-04-01'
group by term
--,payment_instalment	
,payment_frequency	
,payment_number_of_payments	
,payment_number_of_months
,premium_funded
order by 1,2,3

select title
--,ip.* 
,ct.*
from [picllivedb].mbi_cover_type ct
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
order by 1
/*
select distinct status
from (
	select distinct status from [picllivedb].[posm_policy] p
	union
	select distinct status from [picllivedb].[mbi_policy] p
	union
	select distinct status from [picllivedb].[tar_policy] p
	union
	select distinct status from [picllivedb].[gap_policy] p
	union
	select distinct status from [picllivedb].[cci_policy] p
	)X
*/



select 
	t.name		as table_name
	,c.name		as column_name
from sys.tables t
join sys.columns c on c.object_id=t.object_id
where t.name like 'mbi_%'
and (c.name like '%rate%')
order by 2


--MBI POLICY
select * from [picllivedb].[mbi_policy_servicing]
select * from [picllivedb].[mbi_premium_funded]
select * from [picllivedb].[mbi_transfer]
	--select * from [picllivedb].[mbi_refund]	--EMPTY
	--select * from [picllivedb].[mbi_sale]		--EMPTY

--MBI COVER TYPE
select * from [picllivedb].[mbi_cover_type]
select * from [picllivedb].[mbi_cover_type_rate]
select * from [picllivedb].[mbi_cover_type_rule]
	--select * from [picllivedb].[mbi_cover_type_brand]
	--select * from [picllivedb].[mbi_cover_type_details]

select distinct payment_type from [picllivedb].[posm_policy] 