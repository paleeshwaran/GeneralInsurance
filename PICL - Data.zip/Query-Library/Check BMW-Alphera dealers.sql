	--Check BMW / Alphera dealers
	select 
		d.id	as dealer_id
		,company_name
		,d.region_id
		,r.title
		,case 
			when (company_name like '%BMW%' or Company_name like '%alphera%') 
				and d.id not in  (421,531,165,155,163,375,92,99,194,545,175,701,707,187,477,552,551,76,60,186,414,412,356,373,561,704,549,176,562,563,586,644,677,1004,678,680,681,685,686,699)
				then 1 else 0 
				end as check_list
		,is_disabled	
		,is_active	
		,disabled_date	
		,has_signed_agency_agreement	
		,has_signed_posm_agreement	
		,has_posm_luxury_matrix	
		,has_signed_incentive_agreement	
		,dealer_closed	
		,dealer_liquidated
		,use_wholesale_premium
	from [san_posm2].[dealer] d
	left join [san_posm2].region r on r.id=d.region_id
	where 1=1
	/*and ((company_name like '%BMW%' or Company_name like '%alphera%')
		or d.id in (421,531,165,155,163,375,92,99,194,545,175,701,707,187,477,552,551,76,60,186,414,412,356,373,561,704,549
				,176,562,563,586,644,677,1004,678,680,681,685,686,699)
		)*/
	order by 2