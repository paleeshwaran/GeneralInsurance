DECLARE 
	@Reporting_start	datetime = '2020-04-01'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--POLICIES:
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#policies') IS NOT NULL
    DROP TABLE #policies
--POSM-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select top 1
p.id as policy_id
,policy_number 
--,is_renewal
,case when is_renewal=0 then 'New Business' else 'Renewal' end as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'PMV' as SourceTable
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
,payment_freq
,payment_type
,p.term
,refund
,retail_premium_over_term
,premium
,additional_risk_premium
,life_insurance_fee 
,road_side_assist_fee
,p.excess
,sum_insured
,round(premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
--into #policies
from [picllivedb].[posm_policy] p
left join [picllivedb].posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
and invoiced_timestamp>=@Reporting_start --and to_timestamp>=@Reporting_start)

--and policy_number='50032029-1'
--and invoiced_timestamp is null and purchase_timestamp>='2020-12-01'
and p.status='x' and from_timestamp<>to_timestamp

union
--MBI-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'MBI' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,null as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
,p.term
,refund
,dealer_retail_premium as wholesalepremium	
,p.premium  as premium
,0 as additional_risk_premium
,0 as life_insurance_fee
,p.roadside_assist
,excess
,claim_limit
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
from [picllivedb].[mbi_policy] p
left join [picllivedb].mbi_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start --and to_timestamp>=@Reporting_start)
--and status='X' and from_timestamp<>to_timestamp
--and p.roadside_assist<>0

union
--TAR-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'TAR' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,NULL as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
,NULL as payment_freq
,NULL as payment_type
/*,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
*/
--,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
,p.term
,refund
,dealer_retail_premium as wholesalepremium	
,p.premium  as premium
,0 as additional_risk_premium
,0 as life_insurance_fee
,0 as roadside_assist
,excess
,claim_limit_tyres+claim_limit_rims as claim_limit
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
from [picllivedb].[tar_policy] p
left join [picllivedb].tar_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start --and to_timestamp>=@Reporting_start)
--and status='X' and from_timestamp<>to_timestamp
--and premium_funded=1 
union
--GAP-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'GAP' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,NULL as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
/*,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
*/
,NULL as payment_freq
,NULL as payment_type
,p.term
,refund
,dealer_retail_premium 
,p.premium 
,0 as additional_risk_premium
,0 as life_insurance_fee
,0 as roadside_assist
,0 as excess
,gap_amount
--,special_benefits
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
--,p.*
from [picllivedb].[gap_policy] p
left join [picllivedb].gap_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=p.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start

--union
--CCI-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'CCI' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,null as cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
/*,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency*/
,NULL as payment_frequency
,NULL as payment_type
,p.term
,refund
--,dealer_retail_premium as wholesalepremium	
,p.premium  as premium
,0 as additional_risk_premium
,0 as life_insurance_fee
,0 as roadside_assist
--,excess
--,claim_limit
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
,*
from [picllivedb].[cci_policy] p
left join [picllivedb].cci_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start --and to_timestamp>=@Reporting_start)


-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--REFUNDS:
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*--Deactivation Statuses:
select distinct status from [picllivedb].[deactivate_request]

select 
dr.id	as request_id
,dr.policy_id	
,dr.policy_number	
,dr.request_timestamp	
,approved_timestamp
,EOMONTH(approved_timestamp) as month_approved
,dr.cancellation_date
,dr.status
,dr.product_type	
,dr.deactivation_type	
,dr.original_reason
,dr.approved_by_management
,sent_to_xero
,dr.has_mbi_refund_prorata	
,dr.payee_type	
,dr.payee_name	
,dr.deactivation_fee	
,dr.reimbursement_amount	
,dr.gst	
,dr.rebate_adjustment
,dr.*
from [picllivedb].[deactivate_request] dr
	inner join [picllivedb].[mbi_policy] p on p.id=dr.policy_id
where 1=1
and dr.status in ('Processed','Approved','Completed')
and reimbursement_amount<>0.00
and request_timestamp >=@Reporting_start--between '2020-11-01' and '2020-11-30'
*/