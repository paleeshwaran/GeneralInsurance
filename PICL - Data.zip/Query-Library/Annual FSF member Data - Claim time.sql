DECLARE
	@START	datetime = '2020-02-28'
	,@END	datetime = '2021-02-28'

SELECT
	Portfolio,
	 AVG(time_to_subclaim)	as time_to_subclaim
	,AVG(time_to_payment)	as time_to_payment
FROM  (
	select 
	'MVI' as Portfolio
	,c.id as claim_id
	,c.created_timestamp 
	,c.status as claim_status
	,sc.id
	,sc.status
	,sc.created_date
	,sc.paid_timestamp
	,datediff(day,c.created_timestamp,sc.created_date) as time_to_subclaim
	,datediff(day,sc.paid_timestamp,sc.created_date) as time_to_payment
	from [picllivedb].[posm_claim] c 
	left join [picllivedb].[posm_sub_claim] sc on c.id=sc.claim_id
	where 1=1
	and c.created_timestamp>=@START
	--and c.status<>'C'

	union

	select 
	'MBI' as Portfolio
	,c.id as claim_id
	,c.created_timestamp 
	,c.status as claim_status
	,sc.id
	,sc.status
	,sc.created_date
	,sc.paid_timestamp
	,datediff(day,c.created_timestamp,sc.created_date) as time_to_subclaim
	,datediff(day,sc.paid_timestamp,sc.created_date) as time_to_payment
	from [picllivedb].[mbi_claim] c 
	left join [picllivedb].[mbi_sub_claim] sc on c.id=sc.claim_id
	where 1=1
	and c.created_timestamp>=@START
	--and c.status<>'C'

	union

	select 
	'TAR' as Portfolio
	,c.id as claim_id
	,c.created_timestamp 
	,c.status as claim_status
	,sc.id
	,sc.status
	,sc.created_date
	,sc.paid_timestamp
	,datediff(day,c.created_timestamp,sc.created_date) as time_to_subclaim
	,datediff(day,sc.paid_timestamp,sc.created_date) as time_to_payment
	from [picllivedb].[tar_claim] c 
	left join [picllivedb].[tar_sub_claim] sc on c.id=sc.claim_id
	where 1=1
	and c.created_timestamp>=@START
	--and c.status<>'C'

	union

	select 
	'GAP' as Portfolio
	,c.id as claim_id
	,c.created_timestamp 
	,c.status as claim_status
	,sc.id
	,sc.status
	,sc.created_date
	,sc.paid_timestamp
	,datediff(day,c.created_timestamp,sc.created_date) as time_to_subclaim
	,datediff(day,sc.paid_timestamp,sc.created_date) as time_to_payment
	from [picllivedb].[gap_claim] c 
	left join [picllivedb].[gap_sub_claim] sc on c.id=sc.claim_id
	where 1=1
	and c.created_timestamp>=@START
	--and c.status<>'C'

	union
	
	select 
	'CCI' as Portfolio
	,c.id as claim_id
	,c.created_timestamp 
	,c.status as claim_status
	,sc.id
	,sc.status
	,sc.created_date
	,sc.paid_timestamp
	,datediff(day,c.created_timestamp,sc.created_date) as time_to_subclaim
	,datediff(day,sc.paid_timestamp,sc.created_date) as time_to_payment
	from [picllivedb].[gap_claim] c 
	left join [picllivedb].[gap_sub_claim] sc on c.id=sc.claim_id
	where 1=1
	and c.created_timestamp>=@START
	--and c.status<>'C'
	)X
group by Portfolio