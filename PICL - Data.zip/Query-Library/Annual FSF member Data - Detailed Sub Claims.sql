
DECLARE
	@START	datetime = '2020-02-28'
	,@END	datetime = '2021-02-28'

			SELECT 'MVI' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,status
				,paid_timestamp
				,deduct_excess*excess as applied_excess
				,sent_to_xero	
				,ignore_for_xero	
				,send_negative_for_xero
				,actual_cost as total
				,actual_cost-(excess*deduct_excess) total_deduct
				,sent_to_xero*actual_cost as total_xero
				,sent_to_xero*(actual_cost-(excess*deduct_excess)) as total_xero_deduct
				--,*
			FROM [picllivedb].[posm_sub_claim]
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END
	UNION
		SELECT 'MBI'	as Portfolio
		,'Claims Paid'	as Section
				--,p.id	as policy_id
				--,c.id	as claim_id
				,sc.id	as Sub_claim_id
				,increment
				,sc.status
				,paid_timestamp
				,sc.excess*deduct_excess	as applied_excess
				--,p.excess*deduct_excess		as applied_excess
				,sent_to_xero	
				,ignore_for_xero	
				,send_negative_for_xero
				,(total-gst) as Total
				,(total-gst)-(p.excess*deduct_excess) as Total_deduct
				,sent_to_xero*(total-gst) as Total_xero
				,sent_to_xero*((total-gst)-(p.excess*deduct_excess)) as Total_xero_deduct
				--,sc.*
			FROM [picllivedb].[mbi_sub_claim] sc
			left join [picllivedb].[mbi_claim] c
				on sc.claim_id=c.id
			left join [picllivedb].[mbi_policy] p
				on c.policy_id=p.id
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END
	UNION
			SELECT 'TAR' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,status
				,paid_timestamp
				,deduct_excess*excess as applied_excess
				,sent_to_xero	
				,ignore_for_xero	
				,send_negative_for_xero
				,(total-gst)
				,(total-gst)-(excess*deduct_excess) total_deduct
				,sent_to_xero*(total-gst) as total_xero
				,sent_to_xero*((total-gst)-(excess*deduct_excess)) as total_xero_deduct
			FROM [picllivedb].[tar_sub_claim]
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END
	UNION
			SELECT 'CCI' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,status
				,paid_timestamp
				,0 as applied_excess--,deduct_excess*excess as applied_excess
				,sent_to_xero	
				,ignore_for_xero	
				,send_negative_for_xero
				,(total-gst) as total
				,(total-gst)--,total-(excess*deduct_excess) total_deduct
				,sent_to_xero*(total-gst) as total_xero
				,sent_to_xero*(total-gst)--,sent_to_xero*(total-(excess*deduct_excess)) as total_xero_deduct
				--,*
			FROM [picllivedb].[cci_sub_claim]
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END
	UNION
			SELECT 'GAP' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,status
				,paid_timestamp
				,excess_total_loss--,deduct_excess*excess as applied_excess
				,sent_to_xero	
				,ignore_for_xero	
				,send_negative_for_xero
				,total
				,gap_amount--,total-(excess*deduct_excess) total_deduct
				,sent_to_xero*gap_amount as total_xero
				,sent_to_xero*gap_amount--,sent_to_xero*(total-(excess*deduct_excess)) as total_xero_deduct
				--,*
			FROM [picllivedb].[gap_sub_claim]
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END