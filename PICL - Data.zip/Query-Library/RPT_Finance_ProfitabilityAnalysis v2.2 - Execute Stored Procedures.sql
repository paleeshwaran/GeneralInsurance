-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--PROFITABILITY ANALYSIS
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--1)LOAD DATA:
EXEC [Profitablity_test].[dbo].[sp_Profitability_BulkInsert] 
GO
--2)EXECUTE CALCULATION:
EXEC [Profitablity_test].[dbo].[sp_ProfitabilityAnalysis]
GO
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>