USE devsanposm_copy
GO 
SET NOCOUNT ON
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
DECLARE 
	@report_date		datetime	= '2019-10-31',
	@commission_rate	float		= 0.12
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#Carminder_Commission_dealer_group') IS NOT NULL
    DROP TABLE #Carminder_Commission_dealer_group

CREATE TABLE #Carminder_Commission_dealer_group
	(
	dealer_id				INT NOT NULL,
	policy_dealer_name		nvarchar(250) NOT NULL,
	group_name				nvarchar(250) NOT NULL,
	subgroup_name			nvarchar(250) NOT NULL,
	Carminder_Com_Flag		INT NOT NULL,
	Com_Rate				FLOAT NOT NULL
	)
INSERT INTO #Carminder_Commission_dealer_group VALUES(754,'ACU Call Centre','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(757,'ACU Clendon','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(908,'ACU Glen Innes','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(740,'ACU Hamilton','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(752,'ACU Head Office','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(762,'ACU Mangere','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(760,'ACU Otara','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(764,'ACU Papakura','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(755,'ACU Papatoetoe','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(741,'ACU Te Kohao','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(765,'ACU Whanganui','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(910,'ACU Whangarei','Baywide','ACU',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(895,'Credit Union Insurance Direct','Credit Union Insurance Direct','Credit Union Insurance Direct',0,0)
INSERT INTO #Carminder_Commission_dealer_group VALUES(894,'CUI Staff Sales - Business','CUI Staff Sales - Business','CUI Staff Sales - Business',0,0)
INSERT INTO #Carminder_Commission_dealer_group VALUES(917,'Fisher & Paykel Credit Union','Fisher & Paykel','Fisher & Paykel',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1029,'NZCU Auckland - Airport','Auckland','NZCU Auckland',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1028,'NZCU Auckland - Harbour','Auckland','NZCU Auckland',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(766,'NZCU Auckland - Highbrook','Auckland','NZCU Auckland',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(750,'NZCU Auckland - Manukau','Auckland','NZCU Auckland',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(749,'NZCU Auckland - Penrose','Auckland','NZCU Auckland',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(751,'NZCU Auckland - Tip Top','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(777,'NZCU Baywide Dannevirke','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(774,'NZCU Baywide Gisborne','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(770,'NZCU Baywide Hastings','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(763,'NZCU Baywide Lower Hutt','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(761,'NZCU Baywide Masterton','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(772,'NZCU Baywide Napier','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(759,'NZCU Baywide New Plymouth','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(768,'NZCU Baywide Palmerston North','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(758,'NZCU Baywide Porirua','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(771,'NZCU Baywide Taradale','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(756,'NZCU Baywide Wainuiomata','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(776,'NZCU Baywide Waipukurau','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(775,'NZCU Baywide Wairoa','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(753,'NZCU Baywide Wanganui','Baywide','NZCU Baywide',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(748,'NZCU Central Caxton','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(743,'NZCU Central Kawerau','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(745,'NZCU Central Murupara','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(746,'NZCU Central Opotiki','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(742,'NZCU Central Rotorua','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(747,'NZCU Central Te Puke','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(744,'NZCU Central Whakatane - Kopeopeo','Baywide','NZCU Central',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(789,'NZCU Sales and Service Team','NZCU Other','NZCU Other',0,0)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1053,'NZCU South - Dunedin','Baywide','NZCU South',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1054,'NZCU South - Invercargill','Baywide','NZCU South',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1055,'NZCU South - Richmond','Baywide','NZCU South',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(1060,'NZCU South - Sydenham','Baywide','NZCU South',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(911,'NZCU Steelsands C/O NZ Steel Ltd','Steelsands','NZCU Steelsands',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(778,'NZCU Steelsands Southland','SteelSands','NZCU Steelsands',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(909,'NZCU Steelsands Whangarei','SteelSands','NZCU Steelsands',1,0.12)
INSERT INTO #Carminder_Commission_dealer_group VALUES(736,'Provident Direct','Provident Direct','Provident Direct',0,0)

--select * from #Carminder_Commission_dealer_group
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IF OBJECT_ID('tempdb..#policies') IS NOT NULL
    DROP TABLE #policies

select 
policy_number
,p.id												as policy_id
,p.dealer_id	
,com.group_name
,com.subgroup_name
,d.company_name										as policy_dealer_name	
,p.first_name_1										as policy_first_name_1
,p.last_name_1										as policy_last_name_1
,p.product_name
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as policy_product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as policy_cover_type
,p.status											as policy_status
,p.invoiced_timestamp								as policy_invoiced_timestamp	
,p.purchase_timestamp								as policy_purchase_timestamp	
,p.from_timestamp									as policy_from_timestamp	
,p.to_timestamp										as policy_to_timestamp	
,auto_expired_timestamp	
,cancelled_timestamp	
,deactivated_timestamp
,p.payment_freq										as payment_frequency
,p.term												as policy_term	 
,p.premium											as policy_premium 
,wholesalepremium
,com.Com_Rate										as Commission_Rate
,round((p.premium/p.term)*@commission_rate*com.Carminder_Com_Flag,2)	as Raw_Commision
,round((p.premium/p.term)*com.Com_Rate,2)			as Commision
--,p.*
into #policies
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
left join #Carminder_Commission_dealer_group com on com.dealer_id=p.dealer_id
where 1=1
--REPORT FILTERS:
	and ct.id in (3,4) --filter for Carminder product only			--
	and (from_timestamp<=@report_date and to_timestamp>@report_date)	-- 
	--and status='V'														--
	/*--need to check business rules between status flag value and timestamps available:
		and (cancelled_timestamp	is null 
		and  auto_expired_timestamp	is null 
		and  deactivated_timestamp	is null)
	*/
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--TESTING FILTERS:
--and com.Carminder_Com_Flag=1	--filter for Credit Union having a commission calculated for Carminder
--and payment_freq='Y'			--search for a particular payment frequency
--and status<>'V'
--and to_timestamp>='2020-01-01'
--and (cancelled_timestamp is not null and deactivated_timestamp is null)
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
order by p.policy_number desc

/*
select distinct product_name	,ct.title ,ct.*
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
--and ct.id in (3,4) --filter for Carminder product only
and (from_timestamp<=@report_date and to_timestamp>@report_date)
--and status='V'
--and p.policy_number='50009614-9'
*/
/*--check for duplicates
select policy_number,count(*)
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
and ct.id in (3,4) --filter for Carminder product only
and (from_timestamp<=@report_date and to_timestamp>@report_date)
group by policy_number
having count(*)>1
*/
SELECT *
FROM (
	select 
	ROW_NUMBER() OVER (
		partition by policy_status
		order by policy_status, policy_id desc
		)as ROW_NUM
	,policy_number	
	,policy_id
	,policy_status	
	,policy_from_timestamp	
	,policy_to_timestamp	
	,policy_purchase_timestamp	
	,policy_invoiced_timestamp
	,auto_expired_timestamp	
	,cancelled_timestamp	
	,deactivated_timestamp
	from #policies
	)X
--WHERE ROW_NUM<=5
