
select distinct Type
from [dbo].[Load_McLarens_PVT]
where 1=1
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--CLAIMS
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--1)check for duplicates new claims
SELECT * 
FROM [dbo].[Load_McLarens_PVT]
WHERE 1=1
AND Claim_UNID in (
	select Claim_UNID
	from [dbo].[Load_McLarens_PVT]
	where 1=1
	and Type='Claim'
	group by Claim_UNID
	having count(*)>1
	)
--2) Insert 
select 
	Claim_UNID	
	,Change_Date as Created_Date
	,Claim_Date_of_Loss
	,'New' as Claim_Status
	,Claim_Reference
	
	,*
from [dbo].[Load_McLarens_PVT]
where 1=1
and Type='Claim'
--and Policy_Number is null --Claims with no Piclos reference
--and Claim_Reference is null --Claims with no Claim reference
--and Claim_Date_of_Loss is null -- Claims with no date of loss
order by Change_Date


select * 
from [dbo].[Load_McLarens_PVT]
where 1=1
and Type='Claim Change'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--ESTIMATES
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select * 
from [dbo].[Load_McLarens_PVT]
where 1=1
and Type='Estimate'

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--PAYMENTS
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--1) Check for Multiple Payments with the same reference:
SELECT Payment_Ref
	,Payment_Item_Invoice_Number
	,* 
FROM [dbo].[Load_McLarens_PVT]
WHERE 1=1
AND Type='Payment'
AND Payment_Ref in (
	select Payment_Ref
	from [dbo].[Load_McLarens_PVT]
	where 1=1
	and Type='Payment'
	group by Payment_Ref
	having count(*)>1
	)
order by 1 desc

SELECT Payment_Ref
	,Payment_Item_Invoice_Number
FROM [dbo].[Load_McLarens_PVT]
WHERE 1=1
and Type='Payment'
group by Payment_Ref,Payment_Item_Invoice_Number
having count(*)>1

select 
	Claim_UNID	
	,Payment_Ref
	,Policy_Number
	,Change_Date as Created_Date
	,Payment_Section	
	,Payment_Date		
	,Payment_Title	
	,Payment_Status	
	,left(Payment_Type,2) as payment_type_code
	,Payment_Type	
	,Payment_Payee_Name	
	,Payment_Payee_Email	
	,Payment_Payee_Bank_Account_Name	
	,Payment_Payee_Bank_Account	
	,Payment_Item_Description	
	,Payment_Item_Invoice_Number	
	,Payment_Item_Invoice_Date	
	,Payment_Item_Amount_Gross	
	,Payment_Item_Amount_Net	
	,Payment_Item_Amount_Gst	
	,Payment_Prepared_By	
	,Payment_Locked_By	
	,Payment_Locked_On	
	,Include
from [dbo].[Load_McLarens_PVT]
where 1=1
and Type='Payment'
