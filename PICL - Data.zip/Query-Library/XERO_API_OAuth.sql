CREATE TABLE API.App_Parameters
	(
	id					INT	IDENTITY	NOT NULL,
	XERO_App_Name		varchar(250)	NOT NULL,
	client_id			varchar(max)	NOT NULL,
	client_secret		varchar(max)	NOT NULL,
	redirect_uri		varchar(max)	NOT NULL,
	code_challenge		varchar(max)	NULL,
	code_verifier		varchar(max)	NULL,
	xero_tenant_id		varchar(max)	NULL,
	access_token		varchar(max)	NULL,
	access_token_date	datetime		NULL,
	refresh_token		varchar(max)	NULL,
	refresh_token_date	datetime		NULL,
	)

INSERT INTO API.App_Parameters
	(XERO_App_Name		,
	client_id			,
	client_secret		,
	redirect_uri		,
	code_challenge		,
	code_verifier		,
	xero_tenant_id		,
	access_token		,
	access_token_date	,
	refresh_token		,
	refresh_token_date	)
VALUES (												
	'Invoice Extractor'												--XERO_App_Name		
	,'D95B8BEFD6FD40C6A6BAED7E5367926C'								--client_id			,
	,'xz-O1VOx26eMFELIRL8MDzgRv3aZXaNoEZRkSvctHCKPj24P'				--client_secret		,
	,'https://providentinsurance.co.nz'								--redirect_uri		,
	,'uBXSpuV01c4Wj1TM9Zb6Yiog6y3YAYf6VqCcbVVHrQM'					--code_challenge		,
	,'WGVybyBjIGVzdCB2cmFpbWVudCBkZSBsYSBtZXJkZSBqZSB2b3VzIGRpdCA'	--code_verifier		,
	,'27050e88-659a-474e-8ecd-30881957c614'							--xero_tenant_id		,
	,NULL															--access_token		,
	,NULL															--access_token_date	,
	,NULL															--refresh_token		,
	,NULL															--refresh_token_date	
	)


select * from API.App_Parameters