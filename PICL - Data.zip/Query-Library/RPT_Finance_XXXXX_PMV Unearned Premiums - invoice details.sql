


SELECT *
FROM (
	select 
	ROW_NUMBER() OVER (
		partition by payment_type,term
		order by payment_type,term,id desc
		) Row_Num
	,id
	,status
	,invoiced_timestamp 
	,purchase_timestamp
	,payment_type	
	,payment_freq
	,term
	,wholesalepremium
	--,wholesalepremium_over_term
		,isnull(loading_amount,0) as loading_amount
		,isnull(loading_amount_percent,0) as loading_amount_percent --> "premium" need to recalculate based on: wholesalepremium*(1+loading_amount_percent/100)
	,wholesalepremium*(case when loading_amount_percent=0 then 1.00 else isnull(loading_amount_percent,0)
	/100 end)+isnull(loading_amount,0) as Premium_loading
	-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	--GWP
	,premium
	,additional_risk_premium
	,life_insurance_fee 
	--Taxes
	,fire_service_levy
	,gst
	-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	--,fire_service_levy_with_gst_payable
	--,premium_with_gst
	--,premium_with_gst_payable
	--,retail_premium_annual
	--,retail_premium_fortnightly
	--,retail_premium_monthly
	--,retail_premium_over_term
	--,retail_premium_weekly
	,road_side_assist_fee
	--,*
	from picllivedb.posm_policy
	WHERE 1=1
	/*and payment_type in (
		'Dealer Arranged'
		,'Direct Debit'
		,'Automatic Payment'
		,'Credit/Debit Card'
		--'Cheque'
		,'Cash'
		--,'Unknown'
		)
	and status in('V','P')
	--and term <>12
	and premium<>wholesalepremium
	*/
	--and (loading_amount_percent<>0  or loading_amount<>0)
	and id=5111390
	--and id in (5086286,5009532)
	)X
WHERE 1=1
AND Row_Num<=10
AND payment_freq='M'
and term=12
--and id=5103650
order by (premium+additional_risk_premium) desc
/*
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--DEALER ARRANGED INVOICES
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SELECT 
	inp.invoice_id 
	,i.fms_invoice_number
	,inp.policy_id
	,policy_description
	,i.created_date
	,inp.invoice_year		
	,p.from_timestamp	
	,p.to_timestamp	
	,p.term	
	,p.payment_type
	,p.payment_freq
	,i.total
	,inp.gst_rate
	,i.gst	total
	,p.retail_premium_over_term	
	,p.retail_premium_annual	
	,p.retail_premium_monthly	
	,p.retail_premium_fortnightly	
	,p.retail_premium_weekly	
	,p.wholesalepremium_over_term	
	,p.wholesalepremium	
	,p.premium	
	,p.premium_with_gst	
	,p.premium_with_gst_payable	
	,p.loading_amount_over_term	
	,p.loading_amount	
	,p.loading_amount_percent	
	,p.additional_risk_premium	
	,P.gst	
	,p.gst_base_rate	
	,p.dps_convenience_fee	
	,p.fire_service_levy	
	,p.fire_service_levy_base_rate	
	,p.fire_service_levy_with_gst_payable	
	,p.life_insurance_fee	
	,p.life_insurance_fee_base_rate
  FROM picllivedb.[invoice_policy] inp
  LEFT JOIN picllivedb.[invoice] i on i.id=inp.invoice_id
  LEFT JOIN picllivedb.[posm_policy] p on p.id=inp.policy_id
  WHERE 1=1
  --AND payment_type='Dealer Arranged'
  AND policy_id=5111390
  --AND policy_id in (5086286,5009532)
  --AND fms_invoice_number='PICL-0034287'
  /*AND policy_id in (--Examples for report ending 31-08-2020
	5088486								--policy ending 07/30 but auto_expired 08/01
	,5105216							--cancelled renewal (cancellation/deactivation>policy start)
	,5090894							--cancelled during the month -- yearly
	,5092265							--cancelled during the month -- monthly
	,5092356							--cancelled during the month -- fortnightly
	,5092530							--cancelled during the month -- weekly
	,5008455,5008762,5008824,5009532	--36 months example for each period
	,5010007,5011352,5012322,5086286	--36 months Family Finance
	)*/
order by 2 desc

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--DIRECT DEBIT INVOICES
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select 
id	
,posted_to_fms	
,fms_invoice_number	
,xero_invoice_id	
,invoice_timestamp	
,policy_id	
,product	
,gross_premium	
,life_cover	
,gross_fsl	
,gross_fee	
,gst	
,net_total_gst_items	
,gross_total_gst_items	
,total_non_gst_items	
,rounded_payment_amount	
,xero_batch_id	
,piclos_batch_id
from picllivedb.[invoice_direct_debit]
where id in (
	select id--max(id) 
	from picllivedb.[invoice_direct_debit]
	where 1=1
	and policy_id=5111390
	/*and policy_id in (5086286,5009532)/*(--Examples for report ending 31-08-2020
		5088486								--policy ending 07/30 but auto_expired 08/01
		,5105216							--cancelled renewal (cancellation/deactivation>policy start)
		,5090894							--cancelled during the month -- yearly
		,5092265							--cancelled during the month -- monthly
		,5092356							--cancelled during the month -- fortnightly
		,5092530							--cancelled during the month -- weekly
		,5008455,5008762,5008824,5009532	--36 months example for each period
		,5010007,5011352,5012322,5086286	--36 months Family Finance
		)*/
	--and invoice_timestamp<='2020-08-31'
	group by policy_id*/
	)

select * 
from picllivedb.[invoice_policy]
where policy_id in (--Examples for report ending 31-08-2020
	5088486								--policy ending 07/30 but auto_expired 08/01
	,5105216							--cancelled renewal (cancellation/deactivation>policy start)
	,5090894							--cancelled during the month -- yearly
	,5092265							--cancelled during the month -- monthly
	,5092356							--cancelled during the month -- fortnightly
	,5092530							--cancelled during the month -- weekly
	,5008455,5008762,5008824,5009532	--36 months example for each period
	,5010007,5011352,5012322,5086286	--36 months Family Finance
	)

select * from picllivedb.[invoice_vehicle]

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--MBI PREMIUM FUNDED -> MOTORCOVER DIRECT DEBIT
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select * from picllivedb.mbi_premium_funded
select * from picllivedb.invoice_motorcover
*/