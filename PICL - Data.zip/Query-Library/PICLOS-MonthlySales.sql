IF OBJECT_ID('tempdb..#policies') IS NOT NULL
    DROP TABLE #policies

select --top 10000
p.id
,policy_number 
,is_renewal
,case when is_renewal=0 then 'New Business' else 'Renewal' end as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
,cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))		--term after cancellation
	/datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--original term
	as term_prorata
,payment_freq
,payment_type
,p.term
--,retail_premium_over_term	
--,retail_premium_annual	
--,retail_premium_monthly	
--,retail_premium_fortnightly	
--,retail_premium_weekly	
--,wholesalepremium_over_term	
,refund
,wholesalepremium	
,premium--,case when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 0 else premium end as premium
--,round(premium
--	/cast(dateadd(month,p.term,convert(datetime,from_timestamp)) as float)
--	*cast(datediff(day,convert(datetime,from_timestamp),convert(datetime,to_timestamp)) as float)
--	,2)as premium_prorata
,round(premium
	*datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--term after cancellation
	/datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp))	--original term
	,2) as premium_prorata
into #policies
from [picllivedb].[posm_policy] p
left join [picllivedb].posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
and purchase_timestamp>='2019-04-01'
--and invoiced_timestamp is null and purchase_timestamp>='2020-12-01'
--and p.status='x'
--and from_timestamp=to_timestamp
order by 1 desc


select 
month_invoiced
,Sale_Type 
,Cancellation_Type
,product_name	
,cover_type	
,payment_freq
,term
,count(*) as 'Count'
,sum(premium) as Sales
,sum(premium_prorata) Revenue
,avg(premium) as Gross_premium_avg
,avg(premium_prorata) as premium_prorata_avg
from #policies
where 1=1
--and month_invoiced='2020-10-31'
group by 
Sale_Type 
,Cancellation_Type
,product_name	
,cover_type	
,month_invoiced
,payment_freq
,term
order by 1 desc,4,5,2,3

select * 
from #policies
where 1=1
--and month_invoiced='2020-10-31'
and Cancellation_Type='not cancelled'--'Cancelled During Contract' 
and cover_type='Standard'--'Comprehensive'
and payment_freq='W'
and term=24
/*
select 
'posm' as DataSource
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,case when invoiced_timestamp is null then 'Not Invoiced' else 'Invoiced' end as Invoice_Flag
,case when is_renewal=0 then 'New Business' else 'Renewal' end as Sale_Type
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as policy_product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as cover_type
--,p.status											as policy_status
--,payment_freq
--,payment_type
,p.term
,count(*) as 'Count'
,sum(premium) as Premium_total
,avg(premium) as premium_avg
from [picllivedb].[posm_policy] p
left join [picllivedb].posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
and purchase_timestamp>='2019-04-01'
and from_timestamp<>to_timestamp
group by 
EOMONTH(isnull(invoiced_timestamp,purchase_timestamp))
,case when invoiced_timestamp is null then 'Not Invoiced' else 'Invoiced' end
,case when is_renewal=0 then 'New Business' else 'Renewal' end 
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												
--,p.status											
--,payment_freq
--,payment_type
,p.term
*/