--select * from [picllivedb].[tar_policy] p

DECLARE 
	@Reporting_start	datetime = '2020-04-01'
--TAR-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
select --top 1
p.id as policy_id
,convert(varchar,p.id)  as policy_number
,'New Business' as Sale_Type
,case 
	when datediff(day,from_timestamp,dateadd(second,1,to_timestamp))=0 then 'Cancelled At Initiation' 
	else case when p.status='X' then 'Cancelled During Contract' else 'not cancelled' end
	end as Cancellation_Type
,'TAR' as SourceTable
,ip.product_name
,ct.title as cover_type
,EOMONTH(isnull(invoiced_timestamp,purchase_timestamp)) as month_invoiced
,invoiced_timestamp 
,purchase_timestamp
,auto_expired_timestamp
--,cancelled_timestamp
,deactivated_timestamp
,refund_timestamp
,from_timestamp	
,to_timestamp	
,dateadd(month,p.term,from_timestamp) as Original_policy_end
,datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as policy_days_original
,datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as policy_days
,cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)				--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	as term_prorata
/*,case 
	when isnull(p.payment_frequency,'N/A')='N/A' then 'Y'
	when p.payment_frequency='Monthly' then 'M'
	when p.payment_frequency='Fortnightly' then 'F'
	when p.payment_frequency='Weekly' then 'W'
	end as payment_frequency
*/
--,case when p.premium_funded=0 then 'Dealer Arranged' else 'Credit/Debit Card' end as payment_type
,p.term
,refund
,dealer_retail_premium as wholesalepremium	
,p.premium  as premium
,0 as additional_risk_premium
,0 as life_insurance_fee
,0 as roadside_assist
,excess
,claim_limit_tyres+claim_limit_rims as claim_limit
,round(p.premium
	*cast(datediff(day,from_timestamp,dateadd(second,1,to_timestamp)) as float)			--term after cancellation
	/ cast(datediff(day,from_timestamp,dateadd(month,p.term,from_timestamp)) as float)	--original term
	,2) as premium_prorata
from [picllivedb].[tar_policy] p
left join [picllivedb].tar_cover_type	ct	on ct.id=p.cover_type_id	
left join [picllivedb].insurance_product ip on ip.id=ct.insurance_product_id
where 1=1
and invoiced_timestamp>=@Reporting_start --and to_timestamp>=@Reporting_start)
--and status='X' and from_timestamp<>to_timestamp
--and premium_funded=1 

order by 1 desc
