;WITH DEALER AS (
	--Check BMW / Alphera dealers
	select 
		d.id	as dealer_id
		,company_name
		,r.title
		,case 
			when (company_name like '%BMW%' or Company_name like '%alphera%') 
				and d.id not in  (421,531,165,155,163,375,92,99,194,545,175,701,707,187,477,552,551,76,60,186,414,412,356,373,561,704,549,176,562,563,586,644,677,1004,678,680,681,685,686,699)
				then 1 else 0 
				end as check_list
		,is_disabled	
		,is_active	
		,disabled_date	
		,has_signed_agency_agreement	
		,has_signed_posm_agreement	
		,has_posm_luxury_matrix	
		,has_signed_incentive_agreement	
		,dealer_closed	
		,dealer_liquidated
		,use_wholesale_premium
	from [san_posm2].[dealer] d
	left join [san_posm2].region r on r.id=d.region_id
	where 1=1
	and ((company_name like '%BMW%' or Company_name like '%alphera%')
		or d.id in (421,531,165,155,163,375,92,99,194,545,175,701,707,187,477,552,551,76,60,186,414,412,356,373,561,704,549
				,176,562,563,586,644,677,1004,678,680,681,685,686,699)
		)
	--order by 4 desc
	)
/*
IF OBJECT_ID('tempdb..#policies') IS NOT NULL
    DROP TABLE #policies
*/
select 
policy_number
,p.id as policy_id
,p.dealer_id	
,d.company_name		as dealer_name	
,p.interested_parties_id
,p.interested_parties
--,p.first_name_1										
--,p.last_name_1										
,p.product_name
,case 	
	when ct.title='Standard' then 'Provident Motor'				--ct.id=1
	when ct.title='Luxury MV' then 'Provident Motor'			--ct.id=2
	when ct.title='Carminder Comprehensive' then 'Carminder'	--ct.id=3
	when ct.title='Third Party' then 'Carminder'				--ct.id=4
	end												as policy_product_name
,case 
	when ct.title='Carminder Comprehensive' then 'Comprehensive'
	when ct.title='Third Party' then 'Third Party' 
	else ct.title
	end												as cover_type
,p.status											as policy_status
,p.policy_type_id	
,p.is_renewal
,p.payment_type
,p.payment_freq										
,p.term		
,p.premium	
,p.additional_risk_premium
,p.life_insurance_fee
,p.purchase_timestamp									
,p.invoiced_timestamp									
,p.from_timestamp									
,p.to_timestamp	
,auto_expired_timestamp --,isnull(auto_expired_timestamp	,'2999-12-31') as auto_expired_timestamp
,cancelled_timestamp	--,isnull(cancelled_timestamp		,'2999-12-31') as cancelled_timestamp		
,deactivated_timestamp	--,isnull(deactivated_timestamp	,'2999-12-31') as deactivated_timestamp								
,premium_with_gst	
,premium_with_gst_payable
,wholesalepremium
,retail_premium_over_term	
,retail_premium_annual	
,retail_premium_monthly	
,retail_premium_fortnightly	
,retail_premium_weekly	
,wholesalepremium_over_term
--,round((p.premium/p.term)*com.Com_Rate,2)			as Commision
--,p.*
--into #policies
from san_posm2.posm_policy			p
left join san_posm2.dealer			d	on d.id=p.dealer_id
left join san_posm2.customer		c	on c.id=p.customer_id
left join san_posm2.vehicle			v	on v.id=p.vehicle_id
left join san_posm2.posm_cover_type	ct	on ct.id=p.cover_type_id	
where 1=1
--and p.dealer_id in (select dealer_id from DEALER)
and p.id=5090299
--REPORT FILTERS:
	--and invoiced_timestamp<=@report_date	
	--and to_timestamp>=@report_date
	--and (cancelled_timestamp<@report_start_month	
	/*--need to check business rules between status flag value and timestamps available:
		and (cancelled_timestamp	is null 
			and auto_expired_timestamp	is null 
			and deactivated_timestamp	is null)

	*/


/*
select * from [san_posm2].[dealer]  
select * from [san_posm2].[dealer_group]
select * from [san_posm2].[dealer_dealer_group]
select * from [san_posm2].[dealer_group_insurance_products]
select * from [san_posm2].[dealer_posm_brands]
select * from [san_posm2].[dealer_branches]
select * from [san_posm2].[posm_brands]
select * from [san_posm2].[finance_company] order by 2
*/
/*
select * 
from san_posm2.posm_policy

select * 
from san_posm2.posm_claim

select 
	t.name as Table_Name
	,c.name as Column_Name
from sys.tables t
join sys.columns c on c.object_id=t.object_id
where c.name like '%finance_company%'
*/