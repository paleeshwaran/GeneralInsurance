USE prodsqlpiclos
GO

DECLARE
	@START	datetime = '2020-02-28'
	,@END	datetime = '2021-02-28'

	/*
		select 'PMV' as Portfolio
			,'Active Policies' as Section
			,id as policy_id
			,status
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[posm_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END

select status
,sum(case when to_timestamp<=@END then 1 else 0 end) as Expired_Flag
,count(*) 
from [picllivedb].[posm_policy]
group by status
*/
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--Active policies 
	SELECT Portfolio,Section
		,count(*) as Count_Policies
	FROM (
		select 'PMV' as Portfolio
			,'Active Policies' as Section
			,id as policy_id
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[posm_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
		union
		select 'MBI' as Portfolio
		,'Active Policies' as Section
			,id as policy_id
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[mbi_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
	UNION
		select 'TAR' as Portfolio
			,'Active Policies' as Section
			,id as policy_id
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[tar_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
	UNION
		select 'CCI' as Portfolio
			,'Active Policies' as Section
			,id as policy_id
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[cci_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
	UNION
		select 'GAP' as Portfolio
			,'Active Policies' as Section
			,id as policy_id
			,invoiced_timestamp
			,auto_expired_timestamp
			,from_timestamp
			,to_timestamp
			,premium
		from [picllivedb].[gap_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
	UNION
		select 'LNM' as Portfolio
				,'Active Policies' as Section
				,id as policy_id
				,null as invoiced_timestamp
				,null auto_expired_timestamp
				,from_timestamp
				,to_timestamp
				,null as premium
		from [picllivedb].[lnm_policy]
		where 1=1
		and from_timestamp<=@END 
			and to_timestamp>@END
		)X
	GROUP BY Portfolio,Section
	--UNION
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	/*--CLAIMS DATA
	select top 1 * from [picllivedb].[posm_claim]
	select top 1 * from [picllivedb].[posm_sub_claim]
	select top 1 * from [picllivedb].[mbi_claim]
	select top 1 * from [picllivedb].[tar_claim]
	select top 1 * from [picllivedb].[cci_claim]
	select top 1 * from [picllivedb].[gap_claim]
	*/
	SELECT Portfolio,Section
		,sum(total) as Total_Claims
	FROM (
		SELECT 'PMV' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,paid_timestamp
				,total
			FROM [picllivedb].[posm_sub_claim] 
			WHERE paid_timestamp>=@START
			AND paid_timestamp<@END
		UNION
		SELECT 'MBI' as Portfolio
		,'Claims Paid' as Section
				,id
				,increment
				,paid_timestamp
				,total
			FROM [picllivedb].[mbi_sub_claim] 
			WHERE 1=1
			AND from_timestamp<=@END 
				and to_timestamp>@END
		UNION
			SELECT 'TAR' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,paid_timestamp
				,total
			WHERE 1=1
			AND from_timestamp<=@END 
				and to_timestamp>@END
		UNION
			SELECT 'CCI' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,paid_timestamp
				,total
			FROM [picllivedb].[cci_sub_claim]
			WHERE 1=1
			AND from_timestamp<=@END 
				and to_timestamp>@END
		UNION
			SELECT 'GAP' as Portfolio
				,'Claims Paid' as Section
				,id
				,increment
				,paid_timestamp
				,total
			FROM [picllivedb].[gap_sub_claim]
			WHERE 1=1
			AND from_timestamp<=@END 
				and to_timestamp>@END
		)X
	GROUP BY Portfolio,Section
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

