
DECLARE 
	@JW_Threshold		float = 0.85
	,@score_address		float = 75
	,@score_email		float = 23
	,@score_phone		float = 12
	,@score_postcode	float = 1

select 
		isnull(P.Product,P2.Product) as Product
		,isnull(isnull(DS.BusinessID,P.policy_number),P2.id) as policy_number	
		,DS.DebitsuccessID
		,isnull(P.status,P2.status) as status
		,StartDate	,Term	,Instalment
		,DS.Name as DS_ClientName
		,isnull(P.ClientName,P2.ClientName) as ClientName
			--,case when DS.Name COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.ClientName,P2.ClientName) then 0 else 1 end as Flag_Name
		,DS.Address	as DS_ClientAddress
		,isnull(P.ClientAddress2,P2.ClientAddress2) as ClientAddress
			/*
			,CAST(dbo.fn_calculateJaroWinkler(
				dbo.fn_StrClean(DS.Address)
				,dbo.fn_StrClean(isnull(P.ClientAddress,P2.ClientAddress))
				)as decimal(6,2))as JW_score
			*/
			--,case when 	CAST(dbo.fn_calculateJaroWinkler(dbo.fn_StrClean(DS.Address),dbo.fn_StrClean(isnull(P.ClientAddress,P2.ClientAddress)))as decimal(6,2))>=@JW_Threshold
			--	then  else 1 end as Flag_Address
		,LEFT(replace(Address,' ',''),LEN(replace(Address,' ',''))-charindex(';',reverse(replace(Address,' ','')))) as JW_DS_Address
		,LEFT(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ',''),LEN(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ',''))-charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))) as JW_Address
		,REVERSE(LEFT(reverse(replace(Address,' ','')),charindex(';',reverse(replace(Address,' ','')))-1)) as DS_PostCode
		,REVERSE(LEFT(reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')),charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))-1)) as PostCode
			--,case when REVERSE(LEFT(reverse(replace(Address,' ','')),charindex(';',reverse(replace(Address,' ','')))-1))
				--<>REVERSE(LEFT(reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')),charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))-1))
				--then 0 else @score_postcode
		,isnull(DS.Email,'')	as DS_Email
		,isnull(P.email,P2.email) as email
			--,case when isnull(DS.Email,'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.email,P2.email) then 0 else 1 end as Flag_Email
		,case when DS.Phone=DS.email then 1 else 0 end as Email_Preferred
		,case when DS.Phone=DS.email then '' else isnull(replace([dbo].[fn_StrClean_phone](replace(DS.Phone,'0(','(')),' ',''),'') end as DS_Phone
		,DS.Phone
		,isnull(P.day_phone,P2.day_phone) as piclos_phone
		,[dbo].[fn_StrClean_phone](isnull(P.day_phone,P2.day_phone)) as day_phone
		,isnull(P.other_phone,P2.other_phone) as other_phone
		,isnull(P.work_phone,P2.work_phone) as work_phone
			--,case when isnull(replace(DS.Phone,' ',''),'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.day_phone,P2.day_phone) then 0 else 1 end as Flag_Phone
		,case when DS.Phone=DS.email then '' else isnull(RIGHT(replace(DS.Phone,' ',''),4),'') end as DS_Phone_End
		,isnull(isnull(P.Phone_End,P2.Phone_End),'') as Phone_End
			,case when isnull(RIGHT(replace(DS.Phone,' ',''),4),'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.Phone_End,P2.Phone_End) then 0 else 1 end as Flag_Phone_End
		,DS.PayMethod 
		,isnull(P.payment_type,P2.payment_type) as payment_type
			--,case when DS.PayMethod COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_type,P2.payment_type) then 0 else 1 end as Flag_Payment_type
		,DS.Frequency as DS_Frequency
		,isnull(P.payment_freq,P2.payment_freq) as payment_freq
			--,case when DS.Frequency COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_freq,P2.payment_freq) then 0 else 1 end as Flag_Frequency
	--into #temp 
	from dbo.ClientListing DS
	left join [dbo].[Load_PICLOS_ClientListing] P 
		on P.policy_number=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	left join [dbo].[Load_PICLOS_ClientListing] P2
		on P2.id=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	where 1=1
	--and (DS.BusinessID='55125569-2'
	--	or DS.email='skinny987@gmail.com'
	--	or DS.phone='021 087 14336'
	--	)
	--and DS.phone like '%(%'
	order by DS.phone--12



DECLARE 
	@JW_Threshold		float = 0.85
	,@score_email		float = 54
	,@score_address		float = 21
	,@score_postcode	float = 17
	,@score_phone		float = 8
	
select 
product
,policy_number
,status
,DS_ClientName
,ClientName
,case when dbo.fn_calculateJaroWinkler(JW_DS_Address,JW_Address)>=@JW_Threshold then @score_address else 0 end 
	+case when DS_PostCode<>PostCode then 0 else @score_postcode end 
	+case when DS_email<>email then 0 else @score_email end 
	+case when DS_Phone<>day_phone then 0 else @score_phone end as Final_Score
--,'TOTO' as Error
,cast(dbo.fn_calculateJaroWinkler(JW_DS_Address,JW_Address) as decimal(6,2)) as JW_AdressScore
,case when dbo.fn_calculateJaroWinkler(JW_DS_Address,JW_Address)>=@JW_Threshold then @score_address else 0 end as Adress_Score
,case when DS_PostCode<>PostCode then 0 else @score_postcode end as PostCode_Score
,case when DS_email<>email then 0 else @score_email end as Email_Score
,case when DS_Phone<>day_phone then 0 else @score_phone end as Phone_Score
,DS_ClientAddress	
,ClientAddress
,DS_email
,email
,Email_Preferred
,Phone as DS_Phone
,day_phone
--,DS_Phone_End
--,Phone_End
--,case when DS_Phone_End<>Phone_End then 1 else 0 end as Phone_End_Flag
from (
select 
		isnull(P.Product,P2.Product) as Product
		,isnull(isnull(DS.BusinessID,P.policy_number),P2.id) as policy_number	
		,DS.DebitsuccessID
		,isnull(P.status,P2.status) as status
		,StartDate	,Term	,Instalment
		,DS.Name as DS_ClientName
		,isnull(P.ClientName,P2.ClientName) as ClientName
			--,case when DS.Name COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.ClientName,P2.ClientName) then 0 else 1 end as Flag_Name
		,DS.Address	as DS_ClientAddress
		,isnull(P.ClientAddress2,P2.ClientAddress2) as ClientAddress
			/*
			,CAST(dbo.fn_calculateJaroWinkler(
				dbo.fn_StrClean(DS.Address)
				,dbo.fn_StrClean(isnull(P.ClientAddress,P2.ClientAddress))
				)as decimal(6,2))as JW_score
			*/
			--,case when 	CAST(dbo.fn_calculateJaroWinkler(dbo.fn_StrClean(DS.Address),dbo.fn_StrClean(isnull(P.ClientAddress,P2.ClientAddress)))as decimal(6,2))>=@JW_Threshold
			--	then  else 1 end as Flag_Address
		,LEFT(replace(Address,' ',''),LEN(replace(Address,' ',''))-charindex(';',reverse(replace(Address,' ','')))) as JW_DS_Address
		,LEFT(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ',''),LEN(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ',''))-charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))) as JW_Address
		,REVERSE(LEFT(reverse(replace(Address,' ','')),charindex(';',reverse(replace(Address,' ','')))-1)) as DS_PostCode
		,REVERSE(LEFT(reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')),charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))-1)) as PostCode
			--,case when REVERSE(LEFT(reverse(replace(Address,' ','')),charindex(';',reverse(replace(Address,' ','')))-1))
				--<>REVERSE(LEFT(reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')),charindex(';',reverse(replace(isnull(P.ClientAddress2,P2.ClientAddress2),' ','')))-1))
				--then 0 else @score_postcode
		,isnull(DS.Email,'')	as DS_Email
		,isnull(P.email,P2.email) as email
			--,case when isnull(DS.Email,'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.email,P2.email) then 0 else 1 end as Flag_Email
		,case when DS.Phone=DS.email then 1 else 0 end as Email_Preferred
		,case when DS.Phone=DS.email then '' else isnull(replace([dbo].[fn_StrClean_phone](replace(DS.Phone,'0(','(')),' ',''),'') end as DS_Phone
		,DS.Phone
		,isnull(P.day_phone,P2.day_phone) as piclos_phone
		,[dbo].[fn_StrClean_phone](isnull(P.day_phone,P2.day_phone)) as day_phone
		,isnull(P.other_phone,P2.other_phone) as other_phone
		,isnull(P.work_phone,P2.work_phone) as work_phone
			--,case when isnull(replace(DS.Phone,' ',''),'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.day_phone,P2.day_phone) then 0 else 1 end as Flag_Phone
		,case when DS.Phone=DS.email then '' else isnull(RIGHT(replace(DS.Phone,' ',''),4),'') end as DS_Phone_End
		,isnull(isnull(P.Phone_End,P2.Phone_End),'') as Phone_End
			,case when isnull(RIGHT(replace(DS.Phone,' ',''),4),'') COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.Phone_End,P2.Phone_End) then 0 else 1 end as Flag_Phone_End
		,DS.PayMethod 
		,isnull(P.payment_type,P2.payment_type) as payment_type
			--,case when DS.PayMethod COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_type,P2.payment_type) then 0 else 1 end as Flag_Payment_type
		,DS.Frequency as DS_Frequency
		,isnull(P.payment_freq,P2.payment_freq) as payment_freq
			--,case when DS.Frequency COLLATE SQL_Latin1_General_CP1_CI_AS=isnull(P.payment_freq,P2.payment_freq) then 0 else 1 end as Flag_Frequency
	--into #temp 
	from dbo.ClientListing DS
	left join [dbo].[Load_PICLOS_ClientListing] P 
		on P.policy_number=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	left join [dbo].[Load_PICLOS_ClientListing] P2
		on P2.id=DS.BusinessID COLLATE SQL_Latin1_General_CP1_CI_AS
	where 1=1
	--and (DS.BusinessID='55125569-2'
	--	or DS.email='skinny987@gmail.com'
	--	or DS.phone='021 087 14336'
	--	)
	--and DS.phone like '%(%'
	--order by DS.phone--12
	)X
where status='V'
order by 6,7