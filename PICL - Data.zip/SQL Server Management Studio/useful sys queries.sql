
--who modified an object

select 
    so.name, su.name, so.crdate, * 
from 
    sysobjects so 
join 
    sysusers su on so.uid = su.uid  where so.name = 'populate_dim_cover_type'
order by 
    so.crdate


-- --when was a procedure a modified
select name,create_date,modify_date, *
from sys.procedures
order by 3 desc

-- GRANT access to create procedure or table in a database

USE [pi-dwh];
GRANT CREATE PROCEDURE TO "p.sethuramalingam@providentinsurance.co.nz" WITH GRANT OPTION;
GO

GRANT ALTER ON SCHEMA::dbo TO "p.sethuramalingam@providentinsurance.co.nz"
GO

GRANT CREATE TABLE TO "p.sethuramalingam@providentinsurance.co.nz" WITH GRANT OPTION;
GO

GRANT ALTER ON SCHEMA::dbo TO "p.sethuramalingam@providentinsurance.co.nz"
GO

--GRANT access to  in schema

use [pi-dwh]


GRANT ALTER ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

GRANT DELETE ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

GRANT EXECUTE ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

GRANT INSERT ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

GRANT SELECT ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

GRANT UPDATE ON SCHEMA :: sp_data TO "p.sethuramalingam@providentinsurance.co.nz";
GO 



-- GRANT access to EXECUTE in schema
USE [source]
GRANT EXECUTE ON SCHEMA :: dbo TO "p.sethuramalingam@providentinsurance.co.nz";
GO 

USE [source]
GRANT EXECUTE ON SCHEMA :: dbo TO "p.sethuramalingam@providentinsurance.co.nz";
GO 


--USE [Your Database]
--GO
--CREATE ROLE [RoleName1] AUTHORIZATION [dbo]
--GO
--CREATE USER [SQLUser2] FOR LOGIN [SQLUser2]
--GO
--EXEC sp_addrolemember N'p.sethuramalingam@providentinsurance.co.nz', N'SQLUser2'
--GO
--GRANT CREATE PROCEDURE TO [RoleName1]
--GO
--GRANT ALTER ON SCHEMA::dbo TO [RoleName1]
--GO

-- user permission on a database
SELECT DISTINCT pr.principal_id, pr.name, pr.type_desc, 
    pr.authentication_type_desc, pe.state_desc, pe.permission_name
FROM sys.database_principals AS pr
JOIN sys.database_permissions AS pe
    ON pe.grantee_principal_id = pr.principal_id;