/****** Object:  Table [Metadata].[etl_run_history]    Script Date: 5/11/2021 4:02:05 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Metadata].[etl_run_history](
	[etl_his_id] [bigint] IDENTITY(1,1) NOT NULL,
	[processid] [varchar](100) NOT NULL,
	[entity_name] [varchar](100) NOT NULL,
	[etl_fromdate] [datetime] NULL,
	[etl_todate] [datetime] NULL,
	[run_information] [varchar](4000) NULL,
	[run_status] [int] NULL,
	[created_datetime] [datetime] NULL,
	[modified_datetime] [datetime] NULL,
	[process_type] [varchar](20) NULL,
	[extract_row_count] [bigint] NULL,
 CONSTRAINT [pk_bi_ETLRunHistory] PRIMARY KEY NONCLUSTERED 
(
	[etl_his_id] ASC,
	[processid] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[etl_run_history] ADD  DEFAULT (getdate()) FOR [created_datetime]
GO


