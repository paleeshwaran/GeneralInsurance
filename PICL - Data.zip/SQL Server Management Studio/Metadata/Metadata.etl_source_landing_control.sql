/****** Object:  Table [Metadata].[etl_source_landing_control]    Script Date: 5/11/2021 4:02:40 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Metadata].[etl_source_landing_control](
	[etl_sc_id] [bigint] IDENTITY(1,1) NOT NULL,
	[entity_name] [varchar](100) NOT NULL,
	[source_system] [varchar](255) NOT NULL,
	[source_schema_table] [varchar](255) NOT NULL,
	[source_columns] [varchar](max) NOT NULL,
	[watermark_columns] [varchar](510) NULL,
	[where_clause] [varchar](max) NULL,
	[customised_flag] [varchar](1) NULL,
	[low_watermark] [datetime] NULL,
	[high_watermark] [datetime] NULL,
	[created_datetime] [datetime] NULL,
	[source_column_rest_api] [nvarchar](max) NULL,
	[source_column_type_rest_api] [nvarchar](max) NULL,
	[base_url] [nvarchar](256) NULL,
	[relative_url] [nvarchar](256) NULL,
 CONSTRAINT [pk_bi_ETLsourcelanding] PRIMARY KEY NONCLUSTERED 
(
	[etl_sc_id] ASC,
	[entity_name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[etl_source_landing_control] ADD  DEFAULT (getdate()) FOR [created_datetime]
GO


