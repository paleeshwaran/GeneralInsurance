/****** Object:  Table [Metadata].[etl_project_variables]    Script Date: 5/11/2021 4:01:13 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Metadata].[etl_project_variables](
	[etl_pv_id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [varchar](100) NOT NULL,
	[value] [varchar](510) NULL,
	[created_datetime] [datetime] NULL,
 CONSTRAINT [PK_etl_project_variables] PRIMARY KEY NONCLUSTERED 
(
	[etl_pv_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[etl_project_variables] ADD  DEFAULT (getdate()) FOR [created_datetime]
GO


