/****** Object:  Table [Metadata].[etl_entity_control]    Script Date: 5/11/2021 4:00:15 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Metadata].[etl_entity_control](
	[etl_cl_id] [bigint] IDENTITY(1,1) NOT NULL,
	[entity_name] [varchar](100) NOT NULL,
	[connection_string_filepath] [varchar](300) NULL,
	[staging_area] [varchar](100) NULL,
	[increment_control_flag] [int] NULL,
	[full_load_flag] [int] NULL,
	[package_enabled] [int] NULL,
	[control_notes] [varchar](400) NULL,
	[created_datetime] [datetime] NULL,
	[exec_order] [int] NULL,
	[phase] [varchar](70) NULL,
	[subject_area] [varchar](50) NULL,
	[is_hourly] [int] NULL,
	[staging_procedure] [varchar](200) NULL,
	[merging_procedure] [varchar](200) NULL,
	[run_staging_control_flag] [int] NULL,
	[run_control_flag] [int] NULL,
 CONSTRAINT [PK_EA_ETLEntityControl] PRIMARY KEY NONCLUSTERED 
(
	[etl_cl_id] ASC,
	[entity_name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[etl_entity_control] ADD  DEFAULT (getdate()) FOR [created_datetime]
GO

ALTER TABLE [Metadata].[etl_entity_control] ADD  DEFAULT ((0)) FOR [run_staging_control_flag]
GO


