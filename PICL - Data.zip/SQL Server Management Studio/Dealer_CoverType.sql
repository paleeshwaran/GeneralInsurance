-- Generic
select * from picllivedb.dealer_cci_cover_type
select * from picllivedb.dealer_gap_cover_type
select * from picllivedb.dealer_lnm_cover_type
--select * from picllivedb.dealer_lpi_cover_type
select * from picllivedb.dealer_mbi_cover_type
select * from picllivedb.dealer_posm_cover_type
select * from picllivedb.dealer_tar_cover_type

-- Dealer specific
select * from picllivedb.cci_cover_type_dealer
select * from picllivedb.gap_cover_type_dealer
select * from picllivedb.dealer_lnm_cover_type
select * from picllivedb.mbi_cover_type
select * from picllivedb.posm_cover_type_dealer
select * from picllivedb.dealer_tar_cover_type

select * from picllivedb.posm_cover_type_dealer
select * from picllivedb.posm_cover_type_dealer



SELECT d.company_name, d.suburb, d.city, d.accounts_receivable_email, da.bank_account_number, d.use_dd_invoice,
                    CONCAT(u.first_name, ' ', u.last_name) AS sales_rep
                    ,IIF(d.is_disabled='0' AND d.is_active = '1', 'Enabled', 'Disabled') AS [status]
                FROM [picllivedb].[dealer] d
                LEFT JOIN [picllivedb].[dealer_account] da ON d.id = da.dealer_id
                LEFT JOIN  [picllivedb].[dealer_salesrep] ds ON d.id = ds.dealer_id
                LEFT JOIN [picllivedb].[user] u ON ds.user_id = u.id  
                ORDER BY IIF(d.is_disabled='0' AND d.is_active = '1', 'Enabled', 'Disabled') DESC, d.company_name ASC;


select count( dms_list) from picllivedb.dealer where dms_list = ''

select distinct dms_list from picllivedb.dealer

select * from picllivedb.dealer 
where is_disabled is null
order by 1

