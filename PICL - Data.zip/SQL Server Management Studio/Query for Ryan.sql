select
a.product_code, b.dealer_id, b.company_name, b.dealer_group_name, c.cover_description, d.first_name + ' ' + d.last_name as picl_user_name, d.role_name, policy_status_code,
count(Policy_id) PolicyCount, SUM(a.premium_amount) gwp 
from data.dim_policy a
left join ( select distinct dealer_id, dealer_group_name, g.record_current_flag, company_name
				from data.dim_dealer g 
				left join data.dim_dealer_group f on g.dealer_group_id = f.dealer_group_id 
				where g.record_current_flag = 1 and f.record_current_flag = 1 and f.reporting_group_flag = 1 and dealer_active_flag = 1
			) b on a.dealer_id = b.dealer_id and b.record_current_flag = 1
left join data.dim_cover_type c on a.cover_type_id = c.cover_type_id and c.record_current_flag = 1 and cover_active_flag = 1
left join data.dim_user_role d on a.dealer_user_id = d.[user_id] and d.record_current_flag = 1 and user_disabled_flag = 1
where a.record_current_flag = 1
group by a.product_code, b.dealer_id, b.company_name, b.dealer_group_name, c.cover_description, d.first_name + ' ' + d.last_name,  d.role_name, policy_status_code
order by 1 desc

select * from data.dim_policy

--policy 418372
--policy and dealer 424,136
--policy, dealer and cover_type 1,203,511
--policy, dealer, cover_type, user 1,753,081
--Policy, dealer, cover_type, user , product_detail 13,369,249

select count(*) from data.dim_policy where policy_purchase_datetime is null or policy_purchase_datetime = ''

select distinct dealer_user_id, product_code, policy_id, dealer_sales_rep_name, b.first_name + ' ' + b.last_name as salesrepname
from data.dim_policy a 
left join data.dim_user_role b on a.dealer_user_id  = b.user_id

[picllivedb].[dealer_salesrep]

IF OBJECT_ID('tempdb..#policy') IS NOT NULL
DROP TABLE #policy

Select
policy_id
,a.policy_number
,policy_status_code
,underwriting_status
, p.product_description AS [Product]
,cover_type_name
,pd.product_name
,d.company_name
--,Convert(varchar,(ur.first_name + ' ' + ur.last_name)) as [Sales Rep]
,policy_purchase_datetime
,invoiced_datetime
,a.auto_expired_datetime
,a.cancelled_datetime
,a.deactivated_datetime
, policy_valid_from_date
, policy_valid_to_date
,premium_amount
,wholesale_premium_amount 
INTO #policy
FROM data.dim_policy a
LEFT JOIN [Data].[dim_product] p ON p.product_code = a.product_code
LEFT JOIN [Data].[dim_product_detail] pd ON pd.product_id = a.insurance_product_id
LEFT JOIN (select
				DISTINCT dealer_id
				, company_name
				FROM [Data].[dim_dealer]
				WHERE record_current_flag =1 ) AS d ON d.dealer_id = a.dealer_id
--LEFT JOIN [Data].[dim_user_role] ur on a.dealer_sales_rep_name =
-- CASE
-- When ISnumeric(a.dealer_sales_rep_name) = 1 then ur.user_id
-- When IsNumeric(a.dealer_sales_rep_name) = 0 then ur.first_name
-- End
where a.record_current_flag = 1
AND a.policy_id <>0 

Select p.invoiced_datetime
,Product
,product_name
,cover_type_name
,company_name
,[policy_status_code]
,COUNT(policy_id) as [policy_count]
,SUM(premium_amount) as [GWP]from #policy p
GROUP BY p.invoiced_datetime
,Product
,product_name
,cover_type_name
,company_name
,[policy_status_code]
Order by p.invoiced_datetime Desc

