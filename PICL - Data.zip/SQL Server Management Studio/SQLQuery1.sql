--select distinct loan_balance, count(*) from 
--(
--	select first_name_1, last_name_1, dob_1, null as lnm_dob, loan_balance,  id, 'cci' product_type, NULL policy_number  from ext_piclos.cci_policy 
--	union
--	select first_name_1, last_name_1, dob_1, null as lnm_dob,  loan_balance, id, 'gap' product_typ, policy_number from ext_piclos.gap_policy 
--	union
--	select first_name first_name_1, last_name last_name_1, null as dob_1, 
--		case when isdate(dob) = 1 then dob else NULL END as lnm_dob, loan_balance, id, 'lnm' product_type, NULL policy_number from  ext_piclos.lnm_policy 
--	union
--	select first_name_1, last_name_1, dob_1, null as lnm_dob, loan_balance, id, 'mbi' product_type, NULL policy_number from ext_piclos.mbi_policy  
--	union
--	select first_name_1, last_name_1, dob_1, null as lnm_dob, loan_balance, id, 'pmv' product_type, policy_number from ext_piclos.posm_policy  
--	union
--	select first_name_1, last_name_1, dob_1, null as lnm_dob, loan_balance, id , 'tar' product_type, NULL policy_number   from ext_piclos.tar_policy  
--) a 
--where loan_balance > ''  or loan_balance  is not null --

--group  by loan_balance 


--select created_date, purchase_timestamp, from_timestamp, to_timestamp from ext_piclos.lnm_policy --group by loan_balance

--select loan_balance, * from ext_piclos.posm_policy where policy_number like '55137313%'

--select top 3 max(len(loan_balance)) from ext_piclos.posm_policy order by 1 desc
--select top 3 max(len(loan_balance)) from ext_piclos.mbi_policy order by 1 desc
--select top 3 max(len(loan_balance)) from ext_piclos.mbi_policy order by 1 desc

select * from data.dim_user_role

select convert(date, a.policy_purchase_datetime) DateSnapshot, count(Policy_id), SUM(a.premium_amount) from data.dim_policy a
left join data.dim_dealer b on a.dealer_id = b.dealer_id
left join data.dim_cover_type c on a.cover_type_id = c.cover_type_id
left join data.dim_user_role d on a.dealer_user_id = d.[user_id]
left join data.dim_product_detail e on a.product_code = e.product_id