/****** Object:  Table [Data].[dim_product_detail]    Script Date: 22/09/2021 12:32:39 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_product_detail](
	[product_detail_key] [int] IDENTITY(1,1) NOT NULL,
	[product_id] [int] NOT NULL,
	[product_code] [varchar](4) NULL,
	[product_name] [varchar](80) NULL,
	[policy_booklet_version] [bigint] NULL,
	[policy_booklet_name] [varchar](20) NULL,
	[product_active_flag] [bit] NULL,
	[bi_created] [datetime] NULL,
	[last_updated] [datetime] NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_Dim_product_detail_Unique] PRIMARY KEY CLUSTERED 
(
	[product_detail_key] ASC,
	[product_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Data].[dim_product_detail] ADD  DEFAULT (getdate()) FOR [bi_created]
GO

ALTER TABLE [Data].[dim_product_detail] ADD  DEFAULT ((0)) FOR [is_deleted]
GO


