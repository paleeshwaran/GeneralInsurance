/****** Object:  Table [Data].[dim_product]    Script Date: 22/09/2021 12:32:01 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_product](
	[product_key] [int] IDENTITY(1,1) NOT NULL,
	[product_code] [varchar](4) NOT NULL,
	[product_description] [varchar](80) NULL,
	[bi_created] [datetime] NULL,
	[last_updated] [datetime] NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_Dim_Product_Unique] PRIMARY KEY CLUSTERED 
(
	[product_key] ASC,
	[product_code] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Data].[dim_product] ADD  DEFAULT (getdate()) FOR [bi_created]
GO

ALTER TABLE [Data].[dim_product] ADD  DEFAULT ((0)) FOR [is_deleted]
GO


