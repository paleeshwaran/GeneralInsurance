/****** Object:  Table [Data].[dim_dealer]    Script Date: 22/09/2021 12:31:03 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_dealer](
	[dealer_key] [int] IDENTITY(1,1) NOT NULL,
	[generic_cover_type_id] [int] NOT NULL,
	[dealer_specific_cover_type_id] [int] NOT NULL,
	[dealer_id] [int] NOT NULL,
	[dealer_group_id] [int] NOT NULL,
	[company_name] [varchar](80) NOT NULL,
	[registered_company_name] [varchar](80) NOT NULL,
	[registration_number] [varchar](15) NOT NULL,
	[gst_number] [varchar](15) NOT NULL,
	[manager_name] [varchar](40) NOT NULL,
	[physical_address_street_name] [varchar](80) NOT NULL,
	[physical_address_suburb_name] [varchar](80) NOT NULL,
	[physical_address_city] [varchar](80) NOT NULL,
	[physical_address_region_id] [int] NOT NULL,
	[physical_address_postcode] [varchar](6) NOT NULL,
	[postal_address_1] [varchar](80) NOT NULL,
	[postal_address_2] [varchar](80) NOT NULL,
	[postal_address_3] [varchar](80) NOT NULL,
	[postal_postcode] [varchar](6) NOT NULL,
	[phone_number] [varchar](20) NOT NULL,
	[fax_number] [varchar](20) NOT NULL,
	[accounts_receivable_email] [varchar](255) NOT NULL,
	[website_name] [varchar](255) NOT NULL,
	[dms_list] [varchar](255) NOT NULL,
	[primary_contact_firstname] [varchar](80) NOT NULL,
	[primary_contact_lastname] [varchar](80) NOT NULL,
	[primary_contact_email] [varchar](255) NOT NULL,
	[primary_contract_mobile] [varchar](20) NOT NULL,
	[primary_contact_guid] [varchar](40) NOT NULL,
	[secondary_contact_firstname] [varchar](80) NOT NULL,
	[secondary_contact_lastname] [varchar](80) NOT NULL,
	[secondary_contact_email] [varchar](255) NOT NULL,
	[secondary_contract_mobile] [varchar](20) NOT NULL,
	[secondary_contact_guid] [varchar](40) NOT NULL,
	[third_contact_firstname] [varchar](80) NOT NULL,
	[third_contact_lastname] [varchar](80) NOT NULL,
	[third_contact_email] [varchar](255) NOT NULL,
	[third_contract_mobile] [varchar](20) NOT NULL,
	[third_contact_guid] [varchar](40) NOT NULL,
	[dealer_disabled_flag] [bit] NOT NULL,
	[dealer_active_flag] [bit] NOT NULL,
	[dealer_created_date] [datetime] NULL,
	[dealer_disabled_date] [datetime] NULL,
	[has_signed_agency_agreement_flag] [bit] NOT NULL,
	[has_signed_posm_agreement_flag] [bit] NOT NULL,
	[has_posm_luxury_matrix_flag] [bit] NOT NULL,
	[has_signed_incentive_agreement_flag] [bit] NOT NULL,
	[dealer_closed_flag] [bit] NOT NULL,
	[dealer_liquidated_flag] [bit] NOT NULL,
	[dealer_to_competitor_flag] [bit] NOT NULL,
	[dealer_disabled_status_description] [varchar](255) NOT NULL,
	[incentive_account_start_date] [datetime] NULL,
	[incentive_account_end_date] [datetime] NULL,
	[cci_wholesale_premium_flag] [bit] NOT NULL,
	[cci_retail_premium_flag] [bit] NOT NULL,
	[dd_invoice_flag] [bit] NOT NULL,
	[automated_policy_creation_flag] [bit] NOT NULL,
	[automated_motorcentral_flag] [bit] NOT NULL,
	[motorcentral_account_code] [varchar](20) NOT NULL,
	[cci_18_month_flag] [bit] NOT NULL,
	[policy_import_flag] [bit] NOT NULL,
	[has_contract_no_flag] [bit] NOT NULL,
	[cannot_apply_mbi_roadside_assist_flag] [bit] NOT NULL,
	[has_prorata_calculator_mbi_refund_flag] [bit] NOT NULL,
	[use_posm_annual_invoice_flag] [bit] NOT NULL,
	[send_invoice_by_spreadsheet_flag] [bit] NOT NULL,
	[mbi_motorcover_agreement_signed_flag] [bit] NOT NULL,
	[has_giltrap_business_use_enabled_flag] [bit] NOT NULL,
	[credit_union_flag] [bit] NOT NULL,
	[provident_brand_disabled_flag] [bit] NOT NULL,
	[default_brand_id] [bigint] NULL,
	[rating_card_id] [int] NULL,
	[source_system_last_updated_date] [datetime] NULL,
	[crm_guid] [varchar](40) NOT NULL,
	[uses_epb_flag] [bit] NOT NULL,
	[record_start_datetime] [datetime] NULL,
	[record_end_datetime] [datetime] NULL,
	[record_current_flag] [bit] NULL,
	[bi_created] [datetime] NULL,
	[last_updated] [datetime] NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_Dim_Dealer] PRIMARY KEY CLUSTERED 
(
	[dealer_key] ASC,
	[dealer_id] ASC,
	[dealer_specific_cover_type_id] ASC,
	[generic_cover_type_id] ASC,
	[dealer_group_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Data].[dim_dealer] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [record_start_datetime]
GO

ALTER TABLE [Data].[dim_dealer] ADD  DEFAULT ((1)) FOR [record_current_flag]
GO

ALTER TABLE [Data].[dim_dealer] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [bi_created]
GO

ALTER TABLE [Data].[dim_dealer] ADD  DEFAULT ((0)) FOR [is_deleted]
GO


