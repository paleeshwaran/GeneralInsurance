/****** Object:  Table [Data].[dim_cover_type]    Script Date: 22/09/2021 12:26:06 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_cover_type](
	[cover_type_key] [int] IDENTITY(1,1) NOT NULL,
	[cover_type_id] [int] NOT NULL,
	[cover_description] [varchar](80) NULL,
	[cover_active_flag] [bit] NULL,
	[product_id] [int] NOT NULL,
	[product_code] [varchar](4) NOT NULL,
	[dealer_group_id] [int] NULL,
	[dealer_id] [int] NULL,
	[original_cover_type_id] [int] NULL,
	[vehicle_category_id] [int] NULL,
	[maximum_age] [int] NULL,
	[minimum_kms] [int] NULL,
	[maximum_kms] [int] NULL,
	[roadside_assist_top_up_amount] [decimal](10, 2) NULL,
	[roadside_assist_maximum_term_in_months] [int] NULL,
	[petrol_vehicle_service_interval_in_months] [int] NULL,
	[petrol_vehicle_service_kms] [int] NULL,
	[diesel_vehicle_service_interval_in_months] [int] NULL,
	[diesel_vehicle_service_kms] [int] NULL,
	[hybrid_vehicle_service_interval_in_months] [int] NULL,
	[hybrid_vehicle_service_kms] [int] NULL,
	[electric_vehicle_service_interval_in_months] [int] NULL,
	[electric_vehicle_service_kms] [int] NULL,
	[premium_funded_flag] [bit] NULL,
	[flexible_term_flag] [bit] NULL,
	[special_extended_flag] [bit] NULL,
	[gwp_account_number] [int] NULL,
	[cancellation_account_number] [int] NULL,
	[claims_account_number] [int] NULL,
	[posm_roadside_assit_flag] [bit] NULL,
	[posm_term_in_month] [int] NULL,
	[posm_excess_amount] [int] NULL,
	[other_details] [varchar](2000) NULL,
	[additional_notes] [varchar](2000) NULL,
	[financial_rating_notes] [varchar](2000) NULL,
	[acknowledgment_notes] [varchar](2000) NULL,
	[contact_details] [varchar](2000) NULL,
	[use_wholesale_premium_flag] [bit] NULL,
	[rate_12_months_percentage] [decimal](10, 2) NULL,
	[rate_18_months_percentage] [decimal](10, 2) NULL,
	[rate_24_months_percentage] [decimal](10, 2) NULL,
	[rate_36_months_percentage] [decimal](10, 2) NULL,
	[rate_48_months_percentage] [decimal](10, 2) NULL,
	[rate_60_months_percentage] [decimal](10, 2) NULL,
	[rate_double_cover_percentage] [decimal](10, 2) NULL,
	[rate_retail_commission_percentage] [decimal](10, 2) NULL,
	[cover_created_date] [datetime] NULL,
	[cover_enabled_date] [datetime] NULL,
	[created_by_user_id] [int] NULL,
	[record_start_datetime] [datetime] NULL,
	[record_end_datetime] [datetime] NULL,
	[record_current_flag] [bit] NULL,
	[bi_created] [datetime] NULL,
	[last_updated] [datetime] NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_Dim_cover_type] PRIMARY KEY CLUSTERED 
(
	[cover_type_key] ASC,
	[cover_type_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Data].[dim_cover_type] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [record_start_datetime]
GO

ALTER TABLE [Data].[dim_cover_type] ADD  DEFAULT ((1)) FOR [record_current_flag]
GO

ALTER TABLE [Data].[dim_cover_type] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [bi_created]
GO

ALTER TABLE [Data].[dim_cover_type] ADD  DEFAULT ((0)) FOR [is_deleted]
GO


