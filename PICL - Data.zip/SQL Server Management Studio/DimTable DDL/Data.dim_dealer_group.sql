/****** Object:  Table [Data].[dim_dealer_group]    Script Date: 22/09/2021 12:31:34 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_dealer_group](
	[dealer_group_key] [int] IDENTITY(1,1) NOT NULL,
	[dealer_group_id] [int] NOT NULL,
	[dealer_group_name] [varchar](80) NOT NULL,
	[reporting_group_flag] [bit] NULL,
	[group_policies_visible_to_dealers_flag] [bit] NULL,
	[logo_1_filename] [varchar](80) NULL,
	[logo_2_filename] [varchar](80) NULL,
	[dealer_group_created_date] [datetime] NULL,
	[record_start_datetime] [datetime] NULL,
	[record_end_datetime] [datetime] NULL,
	[record_current_flag] [bit] NULL,
	[bi_created] [datetime] NULL,
	[last_updated] [datetime] NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_Dim_Dealer_Group_Unique] PRIMARY KEY CLUSTERED 
(
	[dealer_group_key] ASC,
	[dealer_group_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Data].[dim_dealer_group] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [record_start_datetime]
GO

ALTER TABLE [Data].[dim_dealer_group] ADD  DEFAULT ((1)) FOR [record_current_flag]
GO

ALTER TABLE [Data].[dim_dealer_group] ADD  DEFAULT (((getdate() AT TIME ZONE 'UTC') AT TIME ZONE 'New Zealand Standard Time')) FOR [bi_created]
GO

ALTER TABLE [Data].[dim_dealer_group] ADD  DEFAULT ((0)) FOR [is_deleted]
GO


