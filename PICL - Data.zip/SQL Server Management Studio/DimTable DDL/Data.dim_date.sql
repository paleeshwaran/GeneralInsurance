/****** Object:  Table [Data].[dim_date]    Script Date: 22/09/2021 12:30:30 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Data].[dim_date](
	[date_Key] [int] NOT NULL,
	[day_number] [int] NULL,
	[month_number] [int] NULL,
	[fin_month_number] [int] NULL,
	[month_name] [varchar](9) NULL,
	[month_short_name] [varchar](3) NULL,
	[cal_year_start_date] [date] NULL,
	[cal_year_end_date] [date] NULL,
	[cal_year_day_number] [int] NULL,
	[fin_year_start_date] [date] NULL,
	[fin_year_end_date] [date] NULL,
	[fin_year_day_number] [int] NULL,
	[cal_year] [int] NULL,
	[fin_year] [int] NULL,
	[cal_quarter] [char](3) NULL,
	[fin_quarter] [char](3) NULL,
	[period_number] [int] NULL,
	[period_name] [char](8) NULL,
	[date_value] [date] NULL,
	[season] [varchar](10) NULL,
	[week_day_number] [int] NULL,
	[week_day_name] [varchar](9) NULL,
	[week_day_short_name] [varchar](3) NULL,
	[week_cal_number] [int] NULL,
	[week_fin_number] [int] NULL,
	[fin_year_name] [char](6) NULL,
PRIMARY KEY CLUSTERED 
(
	[date_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


