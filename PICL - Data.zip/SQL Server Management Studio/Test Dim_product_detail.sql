SELECT * FROM [Data].[dim_product]  

select product_detail_key, count(*) from [Data].[dim_product_detail] 
group by product_detail_key having count(*) > 1

select * from [Data].[dim_product_detail]  

SELECT 	product_id id,	product_code product_type--,	product_name,	policy_booklet_version,	policy_booklet_name, product_active_flag is_enabled
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id,	product_type  --,	product_name,	policy_booklet_version,	policy_booklet_name, is_enabled 
from [pi-dwh].ext_piclos.insurance_product

select  id,	product_type,	product_name,	policy_booklet_version,	policy_booklet_name, is_enabled 
from [pi-dwh].ext_piclos.insurance_product
except
SELECT 	product_id id,	product_code product_type,	product_name,	policy_booklet_version,	policy_booklet_name, product_active_flag is_enabled
 FROM [pi-dwh].[Data].[dim_product_detail]  


SELECT 	product_id id
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id   
from [pi-dwh].ext_piclos.insurance_product

SELECT product_id id, product_code product_type
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id , product_type
from [pi-dwh].ext_piclos.insurance_product

SELECT product_id id, product_name
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id , product_name
from [pi-dwh].ext_piclos.insurance_product

SELECT product_id id, policy_booklet_version
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id , policy_booklet_version
from [pi-dwh].ext_piclos.insurance_product

SELECT product_id id, policy_booklet_name
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id , policy_booklet_name
from [pi-dwh].ext_piclos.insurance_product


select  id , policy_booklet_name
from [pi-dwh].ext_piclos.insurance_product
except
SELECT product_id id, policy_booklet_name
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0

SELECT product_id id, product_active_flag is_enabled
 FROM [pi-dwh].[Data].[dim_product_detail]  where product_id <> 0
 except 
select  id , is_enabled
from [pi-dwh].ext_piclos.insurance_product