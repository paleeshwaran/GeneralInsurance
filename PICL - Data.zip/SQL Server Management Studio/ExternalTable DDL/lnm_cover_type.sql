/****** Object:  Table [ext_piclos].[lnm_cover_type]    Script Date: 17/09/2021 1:54:00 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[lnm_cover_type]
(
	[id] [bigint] NOT NULL,
	[insurance_product_id] [bigint] NOT NULL,
	[title] [nvarchar](80) NOT NULL,
	[is_enabled] [bit] NOT NULL,
	[created_timestamp] [datetime2](0) NULL,
	[last_updated] [datetime] NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'lnm_cover_type')
GO


