/****** Object:  Table [ext_piclos].[cci_cover_type]    Script Date: 17/09/2021 1:51:47 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[cci_cover_type]
(
	[id] [bigint] NULL,
	[insurance_product_id] [bigint] NULL,
	[title] [varchar](80) NOT NULL,
	[is_enabled] [bit] NOT NULL,
	[enabled_timestamp] [datetime2](0) NULL,
	[enable_timestamp] [datetime2](0) NULL,
	[use_wholesale_premium] [bit] NOT NULL,
	[contact_details] [varchar](max) NOT NULL,
	[please_note] [varchar](max) NOT NULL,
	[financial_rating] [varchar](max) NOT NULL,
	[acknowledgments] [varchar](max) NOT NULL,
	[other_details] [varchar](max) NOT NULL,
	[rate_percentage_12] [decimal](10, 2) NOT NULL,
	[rate_percentage_18] [decimal](6, 2) NOT NULL,
	[rate_percentage_24] [decimal](10, 2) NOT NULL,
	[rate_percentage_36] [decimal](10, 2) NOT NULL,
	[rate_percentage_48] [decimal](10, 2) NOT NULL,
	[rate_percentage_60] [decimal](10, 2) NOT NULL,
	[rate_double] [decimal](10, 2) NOT NULL,
	[rate_retail_commission] [decimal](6, 2) NOT NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'cci_cover_type')
GO


