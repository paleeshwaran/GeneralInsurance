/****** Object:  ExternalDataSource [linked_sourcedb]    Script Date: 22/09/2021 10:24:09 am ******/
CREATE EXTERNAL DATA SOURCE [linked_sourcedb] WITH (TYPE = RDBMS, LOCATION = N'pi-sqldb-dev-server01-primary.database.windows.net', CREDENTIAL = [CrossDbCred_1], DATABASE_NAME = N'source')
GO


