/****** Object:  Table [ext_piclos].[posm_cover_type]    Script Date: 17/09/2021 1:55:20 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[posm_cover_type]
(
	[id] [bigint] NOT NULL,
	[title] [varchar](80) NOT NULL,
	[gwp_account_code] [bigint] NOT NULL,
	[cancellation_account_code] [bigint] NOT NULL,
	[claims_account_code] [bigint] NOT NULL,
	[has_road_side_assist] [bit] NULL,
	[is_enabled] [bit] NOT NULL,
	[term] [bigint] NOT NULL,
	[excess] [bigint] NOT NULL,
	[other_details] [varchar](max) NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'posm_cover_type')
GO


