/****** Object:  Table [ext_piclos].[tar_cover_type]    Script Date: 17/09/2021 1:55:42 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[tar_cover_type]
(
	[id] [bigint] NOT NULL,
	[dealer_id] [bigint] NOT NULL,
	[original_cover_type_id] [bigint] NOT NULL,
	[insurance_product_id] [bigint] NOT NULL,
	[title] [varchar](80) NOT NULL,
	[is_enabled] [bit] NOT NULL,
	[enabled_timestamp] [datetime2](0) NULL,
	[max_age] [int] NOT NULL,
	[min_kms] [bigint] NOT NULL,
	[max_kms] [int] NOT NULL,
	[created_timestamp] [datetime2](0) NULL,
	[created_by] [bigint] NOT NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'tar_cover_type')
GO


