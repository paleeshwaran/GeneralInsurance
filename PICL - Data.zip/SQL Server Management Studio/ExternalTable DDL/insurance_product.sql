/****** Object:  Table [ext_piclos].[insurance_product]    Script Date: 17/09/2021 1:53:35 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[insurance_product]
(
	[id] [bigint] NOT NULL,
	[product_type] [varchar](4) NOT NULL,
	[product_name] [varchar](80) NOT NULL,
	[policy_booklet_version] [bigint] NOT NULL,
	[policy_booklet_name] [varchar](20) NOT NULL,
	[notes] [varchar](max) NOT NULL,
	[is_enabled] [bit] NOT NULL,
	[enabled_timestamp] [datetime2](0) NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'insurance_product')
GO


