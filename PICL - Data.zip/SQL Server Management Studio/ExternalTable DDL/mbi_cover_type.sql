/****** Object:  Table [ext_piclos].[mbi_cover_type]    Script Date: 17/09/2021 1:54:22 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE EXTERNAL TABLE [ext_piclos].[mbi_cover_type]
(
	[id] [bigint] NOT NULL,
	[dealer_group_id] [bigint] NOT NULL,
	[dealer_id] [bigint] NOT NULL,
	[original_cover_type_id] [bigint] NOT NULL,
	[insurance_product_id] [bigint] NOT NULL,
	[title] [varchar](80) NOT NULL,
	[is_enabled] [bit] NOT NULL,
	[enabled_timestamp] [datetime2](0) NULL,
	[vehicle_category] [bigint] NOT NULL,
	[max_age] [int] NOT NULL,
	[min_kms] [bigint] NOT NULL,
	[max_kms] [int] NOT NULL,
	[roadside_assist] [decimal](10, 2) NOT NULL,
	[roadside_assist_max_term] [bigint] NOT NULL,
	[service_interval_petrol] [int] NOT NULL,
	[service_km_petrol] [int] NOT NULL,
	[service_interval_diesel] [int] NOT NULL,
	[service_km_diesel] [int] NOT NULL,
	[service_interval_hybrid] [bigint] NOT NULL,
	[service_km_hybrid] [bigint] NOT NULL,
	[service_interval_electric] [bigint] NOT NULL,
	[service_km_electric] [bigint] NOT NULL,
	[created_timestamp] [datetime2](0) NULL,
	[created_by] [bigint] NOT NULL,
	[premium_funded] [bit] NOT NULL,
	[is_flexible_term] [bit] NOT NULL,
	[is_special_extended] [bit] NOT NULL
)
WITH (DATA_SOURCE = [linked_sourcedb],SCHEMA_NAME = N'piclos',OBJECT_NAME = N'mbi_cover_type')
GO


