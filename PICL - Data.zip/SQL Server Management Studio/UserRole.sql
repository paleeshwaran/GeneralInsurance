select * from picllivedb.dealer_user where user_id = 4107
select * from picllivedb.import_coop_user where user_id = 4107
select * from picllivedb.[user] where id = 4107
select * from picllivedb.user_cookie where user_id = 4107
select * from picllivedb.user_dealer_group where user_id = 4107
select * from picllivedb.user_role where user_id = 4107
select * from picllivedb.[role]  order by level 

select * from picllivedb.region order by ordering
select * from picllivedb.mvi_region

select * from picllivedb.mvi_region a
full join picllivedb.region b on a.region_name = b.title
where a.region_name is null
--where b.title is null
	 
select * from picllivedb.mvi_region a
full join picllivedb.region b on a.region_name = b.title
--where a.region_name is null
where b.title is null

select case when title is null then region_name else title end as region_name
from picllivedb.mvi_region a
full join picllivedb.region b on a.region_name = b.title

select  a.id, a.title, a.first_name, a.last_name, a.system_reference, a.username, a.email, a.[password], a.is_internal_user,
a.is_disabled, a.disabled_timestamp, a.created_timestamp, a.phone, a.crm_guid, r.title, r.[level], c.id, c.company_name, 
c.suburb, c.city
from picllivedb.[user] a
join picllivedb.user_role  b on a.id = b.user_id
left join (select id, d.company_name, d.suburb, d.city, du.user_id
		from picllivedb.dealer d 
		join picllivedb.dealer_user du on d.id = du.dealer_id 
		) c on c.user_id = a.id
 join  picllivedb.[role] r  on b.role_key = r.[key]
order by first_name, last_name 

select * from picllivedb.dealer_user where user_id = 2640

select * from picllivedb.[user] where first_name = 'Michael' and last_name = 'Elliot'

select  ROW_NUMBER() over (order by d.company_name + d.suburb + d.city) as row_num, d.company_name, d.suburb, d.city, du.*, a.* 
from picllivedb.dealer d 
join picllivedb.dealer_user du on d.id = du.dealer_id 
join picllivedb.[user] a on du.user_id = a.id
order by row_num, a.id

select  a.id, a.username, d.is_disabled, count(dealer_id) 
from picllivedb.dealer d 
join picllivedb.dealer_user du on d.id = du.dealer_id 
join picllivedb.[user] a on du.user_id = a.id
group by a.id, a.username, d.is_disabled
having count(dealer_id) > 1

--"SELECT u.`id`, u.`first_name`, u.`last_name`, u.`email`, u.`username`, u.`is_disabled`, u.`disabled_timestamp`, u.`created_timestamp`,
--    (SELECT CONCAT(d.`company_name`, \'<br \/>\', d.`suburb`, \', \', d.`city`) FROM `dealer` AS d JOIN `dealer_user` AS du ON d.id = du.dealer_id WHERE du.user_id = u.id LIMIT 1) AS company_name
--    FROM `user` AS u '
--' JOIN `user_role` AS ur ON ur.`user_id` = u.`id` ';
--WHERE ur.`role_key` = :role_key"
select * from picllivedb.role

select * from sys.sysobjects