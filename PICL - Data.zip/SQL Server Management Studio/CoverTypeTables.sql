select * from metadata.vw_columns where table_name like '%Claim%'
order by table_name, column_id

select * from metadata.vw_tables where name like '%mvi%'

--use McLarens_Reconciliation 
--go

select * from picllivedb.import_coop_mvi_vehicle_make
select * from picllivedb.import_coop_mvi_vehicle_model

select * from [picllivedb].[insurance_product]

select * from [picllivedb].cci_cover_type 
--select id, created_by from [picllivedb].gap_cover_type 
select * from [picllivedb].lnm_cover_type 
--select id, enabled_timestamp from [picllivedb].lpi_cover_type 
--select id, enabled_timestamp from [picllivedb].mbi_cover_type 
select * from [picllivedb].posm_cover_type 
--select id, enabled_timestamp from [picllivedb].tar_cover_type 

select * from [picllivedb].posm_cover_type

select * from [picllivedb].insurance_product
select * from [picllivedb].lpi_cover_type

-- For cci_cover_type, gap_cover_type, lnm_cover_type, mbi_cover_type, tar_cover_type - join key is insurance_product_id with Dim_ProductDetail.ProductID to get Dim_ProductDetail_Key 
-- For posm_cover_type populate Dim_ProductDetail_Key where Dim_ProductDetail.ProductCode = 'posm' 


--"case when product_type = 'mbi' then 'Mechanical Breakdown Insurnace' 
--     when product_type = 'posm' then 'Private Motor Vehicle'
--	 when product_type = 'lpi' then 'Loan Protection Insurance'
--	 when product_type = 'cci' then 'Credit Contract Indemnity'
--	 when product_type = 'gap' then 'Guaranteed Asset Protection'
--else Product_name end"
