select count(*) from picllivedb.cci_policy
select count(*) from picllivedb.gap_policy
select count(*) from picllivedb.lnm_policy

select count(*) from picllivedb.mbi_policy
select count(*) from picllivedb.posm_policy
select count(*) from picllivedb.tar_policy


select distinct day_phone_prefix, day_phone, other_phone_prefix, other_phone from picllivedb.lnm_policy 
where day_phone_prefix is not null or other_phone_prefix is not null

select distinct day_phone_prefix, day_phone, other_phone_prefix, other_phone from picllivedb.mbi_policy 
where day_phone_prefix is not null or other_phone_prefix is not null

select distinct day_phone_prefix, day_phone, other_phone_prefix, other_phone from picllivedb.tar_policy 
where day_phone_prefix is not null or other_phone_prefix is not null

select * from picllivedb.customer a
LEFT JOIN picllivedb.cci_policy b ON a.id = b.customer_id
where b.customer_id is null

select top 1000 * from picllivedb.customer order by last_updated desc

select count(*) from picllivedb.cci_policy where term <> premium_term 
select count(*) from picllivedb.cci_policy where term = premium_term 
select count(*) from picllivedb.cci_policy where term <> premium_term 

select distinct premium_term  from picllivedb.cci_policy
select distinct term from picllivedb.gap_policy
--select distinct term from picllivedb.lnm_policy

select distinct term from picllivedb.mbi_policy
select distinct insured_person_interest from picllivedb.posm_policy
select distinct term from picllivedb.tar_policy

select * from 
	(
		select 'cci' product, count(*) 'count', format(sum(premium), 'C') premium from picllivedb.cci_policy where status in ('P','V')
		union
		select 'gap' product, count(*) 'count', format(sum(premium), 'C') premium from picllivedb.gap_policy where status in ('P','V')
		union
		select 'lnm' product, count(*) 'count', format(sum(0), 'C') premium from picllivedb.lnm_policy  --where status in ('P','V')
		union
		select 'mbi' product, count(*) 'count', format(sum(premium), 'C') premium from picllivedb.mbi_policy  where status in ('P','V')
		union
		select 'posm' product, count(*) 'count', format(sum(premium), 'C') from picllivedb.posm_policy  where status in ('P','V')
		union
		select 'tar' product, count(*) 'count', format(sum(premium), 'C') from picllivedb.tar_policy  where status in ('P','V')
	) a order by premium desc

select top 1 LEN(policy_notes) lengthmax, policy_notes from picllivedb.posm_policy order by 1 desc

--select case when status = 'C' then 'Closed' 
--			when status = 'E' then 'Auto Expired' 
--			when status = 'F' then 'Force Expired' 
--			when status = 'P' then 'Pending' 
--			when status = 'R' then 'Refunded' 
--			when status = 'V' then 'Invoiced' 
--			when status = 'X' then 'Cancelled' else status end policy_status_description from picllivedb.posm_policy 

select top 10  first_name_1, last_name_1, dob_1, lnm_dob, cover_type_name, id,  product_type,
	case when product_type = 'gap' or product_type = 'pmv' then policy_number else convert(varchar(255), id) end policy_number 
	from 
	 (
	select first_name_1, last_name_1, dob_1, null as lnm_dob, cover_type_name,  id, 'cci' product_type, NULL policy_number  from picllivedb.cci_policy 
	union
	select first_name_1, last_name_1, dob_1, null as lnm_dob, cover_type_name, id, 'gap' product_typ, policy_number from picllivedb.gap_policy 
	union
	select first_name first_name_1, last_name last_name_1, null as dob_1, dob as lnm_dob, cover_type_name, id, 'lnm' product_type, NULL policy_number from  picllivedb.lnm_policy 
	union
	select first_name_1, last_name_1, dob_1, null as lnm_dob, cover_type_name, id, 'mbi' product_type, NULL policy_number from picllivedb.mbi_policy  
	union
	select first_name_1, last_name_1, dob_1, null as lnm_dob, cover_type_name,id, 'pmv' product_type, NULL policy_number from picllivedb.posm_policy  
	union
	select first_name_1, last_name_1, dob_1, null as lnm_dob, cover_type_name, id , 'tar' product_type, NULL policy_number   from picllivedb.tar_policy  
) a 


select top 1 LEN(roadside_breakdown) lengthmax, roadside_breakdown from picllivedb.mbi_policy order by 1 desc
select top 1 LEN(adhoc_dispensation) lengthmax, adhoc_dispensation from picllivedb.tar_policy order by 1 desc

select * from picllivedb.mvi_optional_excess

select commission_rate, count(*) from picllivedb.mbi_policy group by commission_rate
