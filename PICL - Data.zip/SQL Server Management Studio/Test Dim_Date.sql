SELECT count(distinct date_Key) FROM [Data].[dim_date] 
SELECT count(date_Key)FROM [Data].[dim_date]  

SELECT count(date_Key)FROM [Data].[dim_date] where
DATEPART(DAY,date_value) <> [day_number]

SELECT count(date_Key)FROM [Data].[dim_date] where
DATEPART(MONTH,date_value) <> [month_number]

SELECT count(date_Key)FROM [Data].[dim_date] where
(DATEPART(MONTH,date_value) + 8)%12 + 1 <> [fin_month_number]

SELECT count(date_Key)FROM [Data].[dim_date] where
DATENAME(MONTH,date_value) <> [month_name]

SELECT count(date_Key)FROM [Data].[dim_date] where
Convert(char(3), date_value, 0) <> [month_short_name]

select count(*) from [Data].[dim_date] where 
DATEADD(yy, DATEDIFF(yy, 0, date_value), 0) <> cal_year_start_date

select count(*) from [Data].[dim_date] where 
DATEADD(yy, DATEDIFF(yy, 0, date_value) + 1, -1) <> cal_year_end_date

select * from [Data].[dim_date] where DATENAME(dayofyear , date_value) <> cal_year_day_number

select * from [Data].[dim_date] where
case when DatePart(Month, date_value) <= 3
                     then  CONVERT(VARCHAR(4),YEAR(date_value)-1)+ '-04-01'
                    else   
                    convert(varchar(4),DatePart(Year, date_value) )+ '-04-01'
                    end <> fin_year_start_date 

select * from [Data].[dim_date] where
case when DatePart(Month, date_value) <= 3
                     then  CONVERT(VARCHAR(4),YEAR(date_value))+ '-03-31'
                    else   
                    convert(varchar(4),DatePart(Year, date_value) +1)+ '-03-31'
                    end <>  fin_year_end_date
select * from [Data].[dim_date] where DATEDIFF(day, fin_year_start_date, date_value)+1 <> fin_year_day_number
select * from [Data].[dim_date] where DATEPART(YEAR,date_value) <> [cal_year]

select * from [Data].[dim_date] where CASE WHEN DatePart(Month, date_value) >= 4
                     THEN DatePart(Year, date_value) + 1
                     ELSE DatePart(Year, date_value) END  <> [fin_year]
select * from  [Data].[dim_date] where 'Q' + DATENAME(QUARTER,date_value) <> [cal_quarter]

select * from  [Data].[dim_date] where
CASE
					WHEN ((DATEPART(MONTH,date_value) + 8)%12 + 1) IN (1,2,3) THEN 'FQ1'
					WHEN ((DATEPART(MONTH,date_value) + 8)%12 + 1) IN (4,5,6) THEN 'FQ2'
					WHEN ((DATEPART(MONTH,date_value) + 8)%12 + 1) IN (7,8,9) THEN 'FQ3'
					ELSE 'FQ4'
				END <> fin_quarter
select * from  [Data].[dim_date] 
where CAST(CONVERT(CHAR(6),date_value,112) AS INT) <> period_number
select * from  [Data].[dim_date] 
where LEFT(DATENAME(MONTH,date_value),3) + ' ' + CAST(DATEPART(YEAR,date_value) AS CHAR(4)) <> period_name
select * from  [Data].[dim_date] where date_key <> CAST(CONVERT(CHAR(8),date_value,112) AS INT)
select count(*) from  [Data].[dim_date] where
CASE WHEN DATEPART(MM, date_value) in (12, 1, 2) THEN 'Summer' 
                     WHEN DATEPART(MM, date_value) in (3, 4, 5) THEN 'Autumn' 
					 WHEN DATEPART(MM, date_value) in (6, 7, 8) THEN 'Winter'
					 WHEN DATEPART(MM, date_value) in (9, 10, 11) THEN 'Spring' END <> season

--select date_value, week_day_number,	week_day_name,	week_day_short_name, DATEPART(WEEKDAY, date_value)
 select count(*) from  [Data].[dim_date] where 
 case WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Mon' then '1'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Tue' then '2'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Wed' then '3'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Thu' then '4'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Fri' then '5'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Sat' then '6'
	WHEN LEFT(DATENAME(WEEKDAY,date_value),3) = 'Sun' then '7'
 end 
<> week_day_number
select count(*) from  [Data].[dim_date] where DATENAME(WEEKDAY,date_value) <> week_day_name

select count(*) from  [Data].[dim_date] where LEFT(DATENAME(WEEKDAY,date_value),3) <> week_day_short_name

select date_value,	week_day_short_name, DATEPART(WEEK,date_value) , Week_cal_number from  [Data].[dim_date] 
where DATEPART(WEEK,date_value) <> week_cal_number

select Count(*) from  [Data].[dim_date] where
CASE
					WHEN ((DATEPART(MONTH,date_value) + 8)%12 + 1) > 6 THEN 'FY' + CAST(DATEPART(YEAR,date_value) AS CHAR(4))
					ELSE 'FY' + CAST(DATEPART(YEAR,date_value) + 1 AS CHAR(4))
				END <> fin_year_name
